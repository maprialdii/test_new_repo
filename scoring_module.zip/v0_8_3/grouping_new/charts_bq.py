from copy import deepcopy
from itertools import compress

import bqplot as bq
import ipywidgets as widgets
import numpy as np
import pandas as pd
import qgrid
from bqplot.pyplot import vline
from ipywidgets import (
    Accordion,
    BoundedFloatText,
    Button,
    Checkbox,
    Dropdown,
    GridspecLayout,
    HBox,
    IntSlider,
    IntText,
    Label,
    Layout,
    Output,
    Tab,
    Text,
    VBox,
)

from scoring.grouping import _event_rates, woe_scalar

# COLORS = ["lightblue", "darksalmon", "orange", "lightgreen", "mistyrose", "lightgray"]
COLORS = bq.colorschemes.CATEGORY20
CHART_HEIGHT = "250px"
CHART_WIDTH = "250px"


class ChartsSelector:
    def __init__(self):
        self.widget = widgets.VBox(
            [
                widgets.Checkbox(value=True, description="Equifrequency fine classing"),
                widgets.Checkbox(value=True, description="Equidistant fine classing"),
                widgets.Checkbox(value=True, description="Final groups"),
                widgets.Checkbox(value=True, description="Stability bad rate"),
                widgets.Checkbox(value=True, description="Stability population"),
            ],
            layout=widgets.Layout(width="auto"),
        )

        for checkbox in self.widget.children:
            checkbox.observe(self._choose_charts)

        self.selected_charts = [True for _ in self.widget.children]

    def _choose_charts(self, change):
        self.selected_charts = [b.value for b in self.widget.children]


class ChartStability:
    def __init__(self, data):
        self.index = data.index
        self.data = data.T.values
        self.COLORS = COLORS
        self.draw_chart()

    def build_plot(self, x, data):
        # 1. Create the scales
        xs = bq.OrdinalScale()
        ys = bq.LinearScale()

        # 2. Create the axes for x and y
        xax = bq.Axis(
            scale=xs, tick_format="d", grid_lines="none", tick_rotate=45, tick_offset=-10, tick_style={"font-size": 10}
        )
        yax = bq.Axis(
            scale=ys, orientation="vertical", grid_lines="none", tick_format=".0%", tick_style={"font-size": 10}
        )

        # 3. Create a Lines mark by passing in the scales
        # note that Lines object is stored in `line` which can be used later to update the plot
        lines = []
        for pred, color in zip(data, self.COLORS):
            lines.append(bq.Lines(x=x, y=pred, scales={"x": xs, "y": ys}, colors=[color]))

        # 4. Create a Figure object by assembling marks and axes
        fig = bq.Figure(
            marks=lines,
            axes=[xax, yax],
            layout=widgets.Layout(
                width=CHART_HEIGHT, height=CHART_HEIGHT, min_width=CHART_WIDTH, min_height=CHART_WIDTH
            ),
        )

        fig.fig_margin = {"top": 15, "bottom": 30, "left": 35, "right": 15}
        fig.animation_duration = 250
        return fig

    def draw_chart(self):
        self.widget = self.build_plot(x=self.index, data=self.data)

    def update(self, data):
        for i, col in enumerate(data.T.values):
            self.widget.marks[i].y = col
        i += 1
        while i < len(self.widget.marks):
            self.widget.marks[i - 1].y = [0]
            i += 1


class ChartDistribution:
    def __init__(self, index, bar_values, line_values=None, vlines_values=[], colors=COLORS):
        self.x = index
        self.y = bar_values
        self.line_values = line_values
        self.vlines_values = vlines_values
        self.colors = colors
        self.draw_chart()

    def build_plot(self, x, y, line_values=None, vlines_values=[], colors=[]):

        x_sc = bq.LinearScale()
        y_sc = bq.LinearScale(min=0)
        y_red = bq.LinearScale(min=0, max=1)
        bar = bq.Bars(x=x, y=np.nan_to_num(y, nan=0.0), scales={"x": x_sc, "y": y_sc}, colors=colors, padding=-0.2)
        line = bq.Lines(
            x=x,
            y=line_values,
            marker="circle",
            marker_size=30,
            line_style="dotted",
            scales={"x": x_sc, "y": y_red},
            colors=["red"],
        )

        ax_x = bq.Axis(scale=x_sc, grid_lines="none", offset={"value": 0.05})
        ax_y = bq.Axis(scale=y_sc, grid_lines="none", grid_color="gray", orientation="vertical", num_ticks=3)
        ax_y_red = bq.Axis(
            scale=y_red,
            grid_lines="none",
            grid_color="gray",
            orientation="vertical",
            side="right",
            color="red",
            num_ticks=3,
        )

        vlines_marks = []
        vlines_labels = []
        for value in vlines_values:
            vlines_marks.append(vline(value, stroke_width=1, colors=["black"], scales={"x": x_sc, "y": y_sc}))
            vlines_labels.append(
                bq.Label(
                    text=[f"{value:.3f}".rstrip("0").rstrip(".")],
                    colors=["black"],
                    default_size=10,
                    x=[value],
                    y=[1],
                    y_offset=-6,
                    scales={"x": x_sc},
                    align="middle",
                    apply_clip=False,
                    rotation=[0.5],
                    opacity=[0.5],
                )
            )

        fig = bq.Figure(
            marks=[bar, line] + vlines_marks + vlines_labels,
            axes=[ax_x, ax_y, ax_y_red],
            #         title=y.name,
            layout=Layout(width=CHART_WIDTH, height=CHART_HEIGHT, min_width=CHART_WIDTH, min_height=CHART_HEIGHT),
            padding_x=0,
            padding_y=0,
        )

        # fig.fig_margin = {"top": 15, "bottom": 20, "left": 40, "right": 40}
        fig.fig_margin = {"top": 15, "bottom": 30, "left": 35, "right": 15}
        fig.animation_duration = 250

        return fig

    def draw_chart(self):
        self.widget = self.build_plot(
            x=self.x, y=self.y, line_values=self.line_values, vlines_values=self.vlines_values, colors=self.colors
        )

    def update(self, values, index=None):
        self.widget.marks[0].y = values
        if index is not None:
            self.widget.marks[0].x = index


class NumericalChartBox:
    def __init__(self, grouped_table, stability_br, stability_pop, ew_data, ed_data):
        self.grouped_table = grouped_table
        self.stability_br = stability_br
        self.stability_pop = stability_pop
        self.ew_data = ew_data
        self.ed_data = ed_data
        self.draw_charts()

    def draw_charts(self):
        self.charts = []
        self.charts.append(
            ChartDistribution(
                index=range(len(self.ew_data[0]) - 1),
                bar_values=self.ew_data[0],
                line_values=self.ew_data[1],
                vlines_values=self.ew_data[2],
            )
        )

        self.charts.append(
            ChartDistribution(
                index=range(len(self.ed_data[0]) - 1),
                bar_values=self.ed_data[0],
                line_values=self.ed_data[1],
                vlines_values=self.ed_data[2],
            )
        )

        self.charts.append(
            ChartDistribution(
                index=self.grouped_table.index,
                bar_values=self.grouped_table["pop"],
                line_values=self.grouped_table["bad_rate"],
            )
        )
        self.charts.append(ChartStability(self.stability_br))
        self.charts.append(ChartStability(self.stability_pop))

        self.all_charts = [c.widget for c in self.charts]
        self.widget = HBox(self.all_charts)

    def update(self, grouped_table, br_table, pop_table):
        self.charts[2].update(values=grouped_table["pop"], index=grouped_table.index)
        self.charts[3].update(br_table)
        self.charts[4].update(pop_table)

    #         columns = [col for _, col in data.iteritems()]
    #         for chart, col in zip(self.charts, columns):
    #             chart.update(values=col, index=data.index.values)

    def show(self, chosen):
        self.widget.children = tuple(compress(self.all_charts, chosen))


class CategoricalHistogram:
    def __init__(self, data):
        """
        Expects `data` and `grouped_data` exported from CategoricalTab.calculate_hist() etc.
        """
        self.data = deepcopy(data)
        if "group" not in self.data.columns:
            self.data["group"] = range(0, self.data.shape[0])

        self.draw_charts()

    def draw_charts(self):
        self.widget = self._chart(
            x=self.data.index, pop=self.data["pop"], br=self.data["def_rate"], color_by=self.data["group"]
        )

    def _chart(self, x, pop, br, color_by=None):
        if color_by is None:
            colors = COLORS
        else:
            colors_dict = dict(enumerate(COLORS))
            colors = [colors_dict[i] for i in color_by]

        x = x.fillna("Nan")

        x_ord = bq.OrdinalScale()
        y_pop = bq.LinearScale(min=0)
        y_br = bq.LinearScale(min=0, max=1)

        if pd.api.types.is_numeric_dtype(x.dtype):
            x_tick_rotation = 0
        else:
            ## ROTATING IS FUCKED UP
            x_tick_rotation = 0

        ## MARKS
        bar = bq.Bars(x=x, y=pop, scales={"x": x_ord, "y": y_pop}, colors=colors)
        line = bq.Lines(
            x=x,
            y=br,
            scales={"x": x_ord, "y": y_br},
            marker="circle",
            marker_size=30,
            line_style="dotted",
            colors=["red"],
        )

        ## AXES
        ax_x = bq.Axis(
            scale=x_ord,
            tick_rotate=x_tick_rotation,
            grid_lines="none",
            grid_color="white",
            #             visible=False,
        )
        ax_y_pop = bq.Axis(scale=y_pop, tick_format="0.0f", orientation="vertical", grid_lines="none")
        ax_y_br = bq.Axis(
            scale=y_br,
            tick_format="0.0%",
            orientation="vertical",
            side="right",
            color="red",
            num_ticks=3,
            #             offset={"scale": y_br, "value": 0},
            tick_values=[0, 0.5, 1],
            grid_lines="none",
        )

        ## FIG
        fig = bq.Figure(
            marks=[bar, line],
            axes=[ax_x, ax_y_pop, ax_y_br],
            padding_x=0,
            padding_y=0,
            layout=widgets.Layout(
                width=CHART_HEIGHT, height=CHART_HEIGHT, min_width=CHART_WIDTH, min_height=CHART_WIDTH
            ),
        )

        fig.fig_margin = {"top": 15, "bottom": 30, "left": 35, "right": 15}

        return fig


class CategoricalChartBox:
    def __init__(self, histogram, histogram_grouped, stability_pop, stability_br):
        self.histogram = histogram
        self.histogram_grouped = histogram_grouped
        self.stability_br = stability_br
        self.stability_pop = stability_pop
        self.draw_charts()

    def draw_charts(self):
        self.charts = []
        self.charts.append(CategoricalHistogram(self.histogram))
        self.charts.append(CategoricalHistogram(self.histogram_grouped))
        self.charts.append(ChartStability(self.stability_br))
        self.charts.append(ChartStability(self.stability_pop))

        self.all_charts = [c.widget for c in self.charts]
        self.widget = widgets.HBox(self.all_charts)

    def update(self, grouped_table, br_table, pop_table):
        self.charts[2].update(values=grouped_table["pop"], index=grouped_table.index)
        self.charts[3].update(br_table)
        self.charts[4].update(pop_table)

    #         columns = [col for _, col in data.iteritems()]
    #         for chart, col in zip(self.charts, columns):
    #             chart.update(values=col, index=data.index.values)

    def show(self, chosen):
        self.widget.children = tuple(compress(self.all_charts, chosen))
