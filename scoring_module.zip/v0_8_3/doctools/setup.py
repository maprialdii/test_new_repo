from setuptools import setup

setup(name='doctools',
      version='0.2.0',
      description='Tools for scorecard documentations',
      url='http://www.xkd.com',
      author='Vitek',
      author_email='viklepetko@homecreditcfc.cn',
      license='MIT',
      packages=['doctools'],
      zip_safe=False)