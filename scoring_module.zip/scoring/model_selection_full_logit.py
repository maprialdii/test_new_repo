"""
Home Credit Python Scoring Library and Workflow
Copyright © 2017-2019, Pavel Sůva, Marek Teller, Martin Kotek, Jan Zeller, 
Marek Mukenšnabl, Kirill Odintsov, Elena Kuchina, Jan Coufalík, Jan Hynek and
Home Credit & Finance Bank Limited Liability Company, Moscow, Russia.
All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.utils.validation import check_is_fitted
from sklearn.svm import l1_min_c
from sklearn.model_selection import cross_val_score, KFold
from tqdm.notebook import tqdm
import matplotlib.pyplot as plt
from IPython.display import display
import sklearn.linear_model
import sklearn.metrics
import math
from .grouping import Grouping, InteractiveGrouping


class GiniStepwiseFullLogit():

    def __init__(self, initial_predictors = set(), all_predictors = set(),
                 dummy_bindings = None,
                 max_iter=1000, min_increase=0.5, max_decrease=0.25, max_predictors=0,
                 selection_method='stepwise',
                 use_cv=False, cv_folds=5, cv_seed=98765):
        """
        Keyword Arguments:
            initial_predictors {set} -- set of predictors the stepwise should start with. if not filled, it will start with an empty set (default: {set()})
            all_predictors {set} -- set of predictors that would be considered to enter the model. if not filled, all columns in the data served to model in fit() method will be considered. (default: {set()})
            dummy_bindings {Grouping.get_dummies() or InteractiveGrouping.get_dummies() - dictionary} -- dummy variable dictionary from Grouping or InteractiveGrouping (default: {None})
            max_iter {int} -- end after 1000 iterations, if no other stopping criteria fulfilled sooner (default: {1000})
            min_increase {float} -- min gini increase in forward regression step (default: {0.5})
            max_decrease {float} -- max gini decrease in backward regression step (default: {0.25})
            max_predictors {int} -- end when >= max_predictors are in model, if no other stopping criteria fulfilled sooner (default: {0})
            selection_method {str} -- 'forward', 'backward' or 'stepwise' (default: {'stepwise'})
            use_cv {bool} -- should cross validation be used instead of train/validate split? (default: {False})
            cv_folds {int} -- if use_cv: nr of folds in cv (default: {5})
            cv_seed {int} -- if use_cv: random seed for cv (default: {98765})
        """
        
        #set of initial predictors for the first iteration. Can be empty.
        self.initial_predictors = initial_predictors
        #set of all predictors to choose from
        if (len(all_predictors) > 0) and (not initial_predictors.issubset(all_predictors)):
            raise ValueError('all_predictors should be either empty (so all columns will be considered predictors) or initial_predictors must be subset of all_predictors')
        else:
            self.all_predictors = all_predictors
        #maximal number of iterations (forward and backward step of stepwise regression is considered one iteration)
        self.max_iter = max_iter
        #minimal gini increase for forward step (if predictor adds lower increment than this, it should not be added)        
        self.min_increase = min_increase
        #maximal gini decrease for backward step (if predictor lowers gini by more than this, it should not be taken away)
        self.max_decrease = max_decrease
        #maximal number of predictors in model (if exceeded, no forward steps are considered). If set to 0, then ignored. 
        self.max_predictors = max_predictors
        #selection method ('stepwise','forward','backward')
        self.selection_method = selection_method
        #cross validation - boolean if to use it
        self.use_cv = use_cv
        #cross validation folds - number
        self.cv_folds = cv_folds
        #cross validation folds - random seed for shuffling
        self.cv_seed = cv_seed
        
        # bindings between original predictors and dummy variables, mandatory
        if dummy_bindings is None:
            raise ValueError('No full logit constraints received.')
        # test whether we received grouping as the entity with contraints. in such case, they will be in property called dummies
        elif type(dummy_bindings) in (Grouping, InteractiveGrouping):
            self.dummy_bindings = dummy_bindings.get_dummies()
        else:
            self.dummy_bindings = dummy_bindings
        
        # check whether all predictors given by all_predictors and initial_predictors exist also in dummy_bindings
        for predictor in (self.all_predictors | self.initial_predictors):
            if predictor not in self.dummy_bindings.keys():
                raise ValueError('Predictor '+predictor+' not specified in dummy_bindings')

        self.penalty = 'l1'
        self.C = 10e4

    def __cros_val_auc(self, X, y, weights = None):
        #performs crossvalidation training and calculates average (cross)validation Gini

        # convert pandas structures to numpy structures
        X = X.values
        y = y.values
        if weights is not None:
            weights = weights.values

        # stratified k-fold
        kf = KFold(n_splits=self.cv_folds, shuffle=True, random_state=self.cv_seed)
        kf.get_n_splits(X)

        aucs = []

        for train_index, test_index in kf.split(X):

            newModel = LogisticRegression(penalty=self.penalty, C=self.C, solver='liblinear')

            # train/test split
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]

            if weights is not None:
                weights_train, weights_test = weights[train_index], weights[test_index]
                newModel.fit(X_train, y_train, sample_weight=weights_train)
                y_pred = newModel.predict_proba(X_test)[:, 1]
                auc = roc_auc_score(y_test, y_pred, sample_weight = weights_test)

            else:
                newModel.fit(X_train, y_train)
                y_pred = newModel.predict_proba(X_test)[:, 1]
                auc = roc_auc_score(y_test, y_pred)

            # evaluate score metric
            aucs.append(auc)

        avg_auc = sum(aucs)/len(aucs)

        return avg_auc
        
    def __one_model(self, X, y, X_valid, y_valid, sample_weight = None, sample_weight_valid = None):
        #calculates a regression model on the given set and with given parameters
        #returns its gini and indicator whether the betas have the same signum   
    
        #train model using training sample
        #this must be done even for Cross Validation !!!
        #the reason is: criteria as same beta signum must be evaluated on one firm set of coefficients
        newModel = LogisticRegression(penalty=self.penalty, C=self.C, solver='liblinear')
        #if there is a variable with weights, use weighted regression
        if sample_weight is None:
            newModel.fit(X, y)
        else:
            newModel.fit(X, y, sample_weight)

        # without Cross Validation
        if not (self.use_cv):
            #measure Gini of such model
            predictions = newModel.predict_proba(X_valid)[:, 1]
            if sample_weight_valid is None:
                gini_result = 200*roc_auc_score(y_valid,predictions)-100
            else:
                gini_result = 200*roc_auc_score(y_valid,predictions,sample_weight=sample_weight_valid)-100

        # with Cross Validation
        else:
            #the weight is None codition is resolved inside the called function
            cv_auc = self.__cros_val_auc(X, y, sample_weight)
            gini_result = 200*cv_auc-100
            
        return gini_result
    
    def __find_same_model(self, predictor_set, allModels):
        #determine whether there is already model with given predictors set in allModels
                
        #if such model was calculated before, use numbers from the previous calculation
        same_model_list = (list(filter(lambda model: model['predictors'] == predictor_set, allModels)))
         
        #number of same models already calculated
        same_model_count = len(same_model_list)
        
        #assign values from the first same model or empty values
        if same_model_count > 0:
            gini_result = same_model_list[0]['Gini']
            used_before = same_model_list[0]['used']
        else:
            gini_result = None
            used_before = None
            
        return same_model_count, gini_result, used_before
    
    def __filter_possible_models(self, iterNum, allModels, incdec):
        #filter models which are feasible based on given criteria
    
        if incdec == 'inc':
            #filter models that meet criteria: was not used before, Gini increment >= min_increase
            possibleModels = list(filter(lambda model: model['iteration']==iterNum and model['addrm']==1 and
                                         model['used']==0 and model['diff']>=self.min_increase, allModels))

        elif incdec == 'dec':
            #filter models that meet criteria: was not used before, Gini decrease <= max_decrease
            possibleModels = list(filter(lambda model: model['iteration']==iterNum and model['addrm']==-1 and
                                         model['used']==0 and model['diff']>=-self.max_decrease, allModels))
            
        else:
            possibleModels = allModels    
            
        #order such models by added Gini desc
        possibleModels = sorted(possibleModels, key = lambda d: d['diff'], reverse = True)
        
        #if there is such model used flag must be updated
        if len(possibleModels) > 0:
            toUpdateModels = list(filter(lambda model: model['predictors']==possibleModels[0]['predictors'], allModels)) 
            toUpdateModels = [m.update({'used':1}) for m in toUpdateModels]
        
        return possibleModels, allModels

    def __dummy_variable_set(self, predictor_set, column_set, nuniques, X):
        #for given set of predictors (predictor_set), this finds dummy variables in column_set related to these predictors, using relationships given by self.dummy_bindings

        variable_tmp_set = set()

        # for each predictor, add dummies related to it into a temporary dummy set.
        # the task is to add only such dummies that are linearly independent, i.e. we have to omit one of them (as together, they add up to vector of ones) and we also have to omit trivial dummies (vectors of zeros) if they exist
        for predictor in predictor_set:
            first = True
            for variable in self.dummy_bindings[predictor]:
                if variable in column_set:
                    # first of the dummies for each original predictor will NOT enter the column set to solve linear dependency
                    if first:
                        first = False
                    # dummy which has only 1 or 0 unique value will NOT enter the column set as it is useless and linearly dependent with everything
                    elif nuniques[variable] <= 1:
                        pass
                    # if both previous conditions are false, the dummy WILL enter the column set
                    else:
                        variable_tmp_set.add(variable)

        variable_set = set()

        # check whether the dummy set does not include two variables which have identical values (might hapen mainly with dummies for NaN values for predictors that came from the same source)
        for variable in variable_tmp_set:
            identity_found = False
            # search all dummies that already have been added into the final set
            for previous_variable in variable_set:
                # if identical variable was no found yet, check identity
                if not identity_found:
                    identity_found = X[previous_variable].equals(X[variable])
            # if and identical variable was found, we will not add "variable" to the final variable set (as the identical is already there). otherwise, we add it
            if not identity_found:
                variable_set.add(variable)

        return variable_set
    
    def fit(self, X, y, X_valid = None, y_valid = None, sample_weight = None, sample_weight_valid = None):
        """fit regression model while iterating in stepwise/forward/backward way
        
        Arguments:
            X {pd.DataFrame} -- df with predictors - training sample
            y {pd.Series} -- target - training sample
        
        Keyword Arguments:
            X_valid {pd.DataFrame} -- df with predictors - validation sample. if unspecified, training sample is used for validation. if use_cv = True in object initialization, both train and validation sample are used for cv folds. (default: {None})
            y_valid {pd.Series} -- target - validation sample. if unspecified, training sample is used for validation. if use_cv = True in object initialization, both train and validation sample are used for cv folds. (default: {None})
            sample_weight {pd.Series} -- obervarion weights - training sample. if unspecified, weights = 1 for each observation are used. (default: {None})
            sample_weight_valid {pd.Series} -- obervarion weights. if unspecified, weights = 1 for each observation are used. (default: {None})
        """

        if self.use_cv:
            if (X_valid is not None) or (y_valid is not None):
                print('Cross validation will be used for the union of training and validation sample.')
                print('If you want to use cross validation for training sample only, do not submit any validation sample.')
                X = pd.concat([X, X_valid])
                y = pd.concat([y, y_valid])
                X_valid = X
                y_valid = y
                if sample_weight is not None:
                    sample_weight = pd.concat(sample_weight, sample_weight_valid)
                else:
                    sample_weight = None
                sample_weight_valid = sample_weight
            else:
                print('Cross validation will be used for the training sample.')
                X_valid = X
                y_valid = y
                sample_weight_valid = sample_weight
        else:
            if (X_valid is not None) and (y_valid is not None):
                print('Regression will be trained using training sample, Gini will be evaluated using validation sample.')
            else:
                X_valid = X
                y_valid = y
                sample_weight_valid = sample_weight
                print('No validation sample submitted, Gini will be evaluated using training sample.')

        # sanity check - number of unique values in each column must be > 1
        nuniques = X.nunique()
        
        # if all_predictors is empty, it means that we want use all variables of X as potential predictive columns, so we add all predictors we find in X to all_predictors
        if len(self.all_predictors) == 0:
            for column in X.columns:
                for predictor_name, predictor_dummies in self.dummy_bindings:
                    if column in predictor_dummies:
                        self.all_predictors.add(predictor_name)

        #make sure that min_increase > max_decrease >= 0 - otherwise there might be an infinite loop
        if self.max_decrease < 0:
            self.max_decrease = 0
            print('max_decrease parameter was invalid, it is set to 0 now.')
        if self.min_increase <= self.max_decrease:
            self.min_increase = self.max_decrease+0.01
            print('min_increase parameter was <= max_decrease, it is set to max_decrease+0.01 now')
            
        #init variable consolidating stopping criteria
        stopNow = 0
        #init variable with current step number
        iterNum = 0
        print("Iteration ",iterNum)
        #init set of currently used predictors
        modelID = 0
        
        #number of predictors in the initial set
        newPredNum = len(self.initial_predictors)
        newPredSet = self.initial_predictors
        newDummySet = self.__dummy_variable_set(newPredSet, set(X.columns), nuniques, X)
        
        #there are some predictors in the inital set, the create the initial model of it
        if newPredNum > 0:
        
            #logit regression
            newGini = self.__one_model(X[list(newDummySet)], y, X_valid[list(newDummySet)], y_valid, sample_weight, sample_weight_valid)
    
        #the inital set of predictors is empty, then the model has 0 Gini
        else:
            newGini = 0
            
        #init data structure with all models so far
        #iteration number, add or remove, set of predictors, number of predictors, Gini, Gini difference, model used
        allModels = [{'ID':modelID,'iteration':0,'addrm':0,'predictors':newPredSet,
                      'prednum':newPredNum,'Gini':newGini,'diff':0,
                      'used':1}]
        
        #output to screen
        print()
        print(f"Iter    Gini    GiniΔ  #Pred   AddedPred                                RemovedPred")
        print(f"[{iterNum:>2}]   {newGini:>5.2f}              {newPredNum:<5}{newPredSet}")
        
        #go to step 1
        iterNum = iterNum + 1
        if iterNum > self.max_iter:
            stopNow = 1
            currentModel = allModels[0]

        #iterate until stopping criteria met
        while stopNow == 0:
                    
            #find the model we want to tune
            originalModel = (list(filter(lambda model: model['iteration']==iterNum-1 and model['addrm']==0, allModels)))[0]
            
            #get the Gini of this model from the previous step
            currentModel = originalModel
            currentGini = currentModel['Gini']
            addedPredictor = None
            removedPredictor = None

            #check whether current number of predictors == max_predictors parameter value
            if ((self.selection_method=='stepwise') or (self.selection_method=='forward')) and (
            (currentModel['prednum'] < self.max_predictors) or (self.max_predictors <= 0)):
                
                #we still can add more predictors
                #iterate through all unused predictors
                for newPredictor in self.all_predictors - currentModel['predictors']:
                    
                    #try model with addition of new predictor
                    newPredSet = currentModel['predictors'] | {newPredictor}
                    newDummySet = self.__dummy_variable_set(newPredSet, set(X.columns), nuniques, X)
                    
                    #if such model was calculated before, use numbers from the previous calculation
                    sameModelCnt, newGini, usedBefore = self.__find_same_model(newPredSet, allModels)

                    #else calculate the model now
                    if sameModelCnt < 1:
                        #logit regression - use special function
                        newGini = self.__one_model(X[list(newDummySet)], y, X_valid[list(newDummySet)], y_valid, sample_weight, sample_weight_valid)
                        usedBefore = 0
                        
                    #add to data structure
                    modelID = modelID + 1
                    allModels.append({'ID':modelID,'iteration':iterNum,'addrm':1,'predictors':newPredSet,
                                      'prednum':len(newPredSet),'Gini':newGini,'diff':newGini-currentGini,
                                      'used':usedBefore})
            
                #filter only models fulfilling criteria to be used
                possibleModels, allModels = self.__filter_possible_models(iterNum, allModels, incdec='inc')
                    
                #if there is such model, set that the selected model is the current one
                if len(possibleModels) > 0:
                    currentModel = possibleModels[0]
                    currentGini = currentModel['Gini']
                    addedPredictor = (currentModel["predictors"] - originalModel["predictors"]).pop()

                #else the original model proceeds to the next step       

            #if more than one predictor, try to remove one
            if ((self.selection_method=='stepwise') or (self.selection_method=='backward')) and currentModel['prednum'] > 1:
                
                #iterate through all used predictors
                for remPredictor in currentModel['predictors']:
                
                    #try model with removal of one predictor
                    newPredSet = currentModel['predictors'] - {remPredictor}
                    newDummySet = self.__dummy_variable_set(newPredSet, set(X.columns), nuniques, X)
                
                    #if such model was calculated before, use numbers from the previous calculation
                    sameModelCnt, newGini, usedBefore = self.__find_same_model(newPredSet, allModels)

                    #else calculate the model now
                    if sameModelCnt < 1:
                        #logit regression - use special function
                        newGini = self.__one_model(X[list(newDummySet)], y, X_valid[list(newDummySet)], y_valid, sample_weight, sample_weight_valid)
                        usedBefore = 0
                    
                    #add to data structure
                    modelID = modelID + 1
                    allModels.append({'ID':modelID,'iteration':iterNum,'addrm':-1,'predictors':newPredSet,
                                      'prednum':len(newPredSet),'Gini':newGini,'diff':newGini-currentGini,
                                      'used':usedBefore})
            
                #filter only models fulfilling criteria to be used
                possibleModels, allModels = self.__filter_possible_models(iterNum, allModels, incdec='dec')
                    
                #if there is such model, set that the selected model is the current one
                if len(possibleModels) > 0:
                    currentModel = possibleModels[0]
                    currentGini = currentModel['Gini']
                    removedPredictor = (originalModel["predictors"] - currentModel["predictors"]).pop()

                #else the original model proceeds to the next step    
                
            #add the basic model for the next iteration to the data set
            modelID = modelID + 1
            allModels.append({'ID':modelID,'iteration':iterNum,'addrm':0,'predictors':currentModel['predictors'],
                              'prednum':currentModel['prednum'],'Gini':currentModel['Gini'],
                              'diff':0,'used':1})
            
            #new iteration number
            iterNum = iterNum + 1
            
            
            
            changedGini = currentGini - originalModel["Gini"]

            #output predictor list and Gini to screen
            print(f"[{iterNum:>2}]   {currentModel['Gini']:>5.2f}   {changedGini:>+6.2f}    {currentModel['prednum']:>2}    {addedPredictor if addedPredictor else '':<40} {removedPredictor if removedPredictor else ''}")
            
            #if the model proceeding to the next iteration is the original model or maximal interation number achived, stop
            if (currentModel == originalModel) or (iterNum > self.max_iter):
                stopNow = 1
        
        #output attributes creation            
        #set data frame with all iterations
        self.model_progress_ = pd.DataFrame.from_records(allModels)
        
        #set final model description
        self.final_predictors_orig_ = list(currentModel['predictors'])
        self.final_predictors_ = list(self.__dummy_variable_set(set(self.final_predictors_orig_), set(X.columns), nuniques, X))

        #fits the final model
        self.final_model_ = LogisticRegression(penalty=self.penalty, C=self.C, solver='liblinear')    
        if sample_weight is None:
            self.final_model_.fit(X[self.final_predictors_], y)
        else:
            self.final_model_.fit(X[self.final_predictors_], y, sample_weight)
                
        self.coef_ = self.final_model_.coef_
        self.intercept_ = self.final_model_.intercept_

        return self
    
    def predict(self, X):
    #uses the fitted final model to calculate predictions
        
        check_is_fitted(self,['model_progress_','final_predictors_','final_model_'])
        
        #calculates the predicted probabilities
        y = self.final_model_.predict_proba(X[self.final_predictors_])[:, 1]
        
        return y

    def draw_gini_progression(self, output_file=None):
        """Draws progression plot of gini values during step-wise fitting.

        Plots values of gini based on step during step-wise fitting of model.

        Args:
            output_file (str, optional): relative path to file to export

        Returns:
            None
            Draws a plot with mathplotlib to notebook. 

        """
        it = range(0,len(self.model_progress_[self.model_progress_['addrm']==0]['prednum']))
        pn = self.model_progress_[self.model_progress_['addrm']==0]['prednum']
        ginis = self.model_progress_[self.model_progress_['addrm']==0]['Gini']
        plt.figure(figsize = (7,7))
        plt.plot(it, ginis)
        ymin, ymax = plt.ylim()
        plt.xlabel('Iteration')
        plt.ylabel('Gini')
        plt.title('Stepwise model selection')
        plt.axis('tight')
        if output_file is not None:
            plt.savefig(output_file, bbox_inches='tight', dpi = 72)
        plt.show()
        plt.clf()
        plt.close()

    def print_final_model(self):
        """Exports final model to pd.Dataframe.

           Multiindex is used for original and dummy predictors,
           coefficiets are in the only value column.
        Returns:
            [pd.df]: model table
        """
        final_preds = self.final_predictors_
        coefs = self.coef_[0]
        intercept = self.intercept_[0]
        
        inverted_dummy = {}
        for orig, dummies in self.dummy_bindings.items():
            for dummy in dummies:
                inverted_dummy[dummy] = orig
        
        
        coefs =[coef for pred,coef in  sorted(zip(final_preds,coefs))]
        final_preds = sorted(final_preds)
        orig_preds = [inverted_dummy[final_pred] for final_pred in final_preds]
        
        m_index = pd.MultiIndex.from_arrays([["", *orig_preds], ["Intercept", *final_preds]], names=["Original", "Dummy"])
        
        return pd.DataFrame(data=[intercept, *coefs], index=m_index, columns=["Coefficient"])