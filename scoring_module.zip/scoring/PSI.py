"""
Home Credit Python Scoring Library and Workflow
Copyright © 2017-2019, Pavel Sůva, Marek Teller, Martin Kotek, Jan Zeller, 
Marek Mukenšnabl, Kirill Odintsov, Elena Kuchina, Jan Coufalík, Jan Hynek and
Home Credit & Finance Bank Limited Liability Company, Moscow, Russia.
All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

# coding: utf-8


get_ipython().magic('matplotlib inline')

import matplotlib.pyplot as plt
import numpy as np




def psi(x, y, bins=10):
    """
    PSI metric for month y relatively to the month x
    """
    bins=np.percentile(x, np.linspace(0,100,bins))
    
    freqs,bins=np.histogram(x, bins=bins)
    freqs=freqs*1.0/np.sum(freqs)
    
    freqs2, _=np.histogram(y, bins)
    freqs2=freqs2*1.0/np.sum(freqs2)
    
    ps=np.sum((freqs-freqs2)*np.log(freqs/freqs2))
    return ps



def psi_comparison_chart(months, psi_array, labels_array, title='PSI', size=(12, 8)):
    """
    Draws histogram of psi:
    Arguments:
        months: array like
            months for which psi is calculated
        psi_array: array like
            array of psi arrays, every psi array contains psi fro each month from months
        labels_array: array like
            array of strings - labels for every psi array on histogram
        title: optional, default 'PSI'
            title of the histogram
        size: optional, default (12,8)
            size of the histogram
    """
    #if len(psi_array) == 1:
    #    psi_chart(months, psi_array[0], title=labels_array[0])
    #else:
    plt.figure(figsize=size)
    plt.grid(zorder=0)
    X = np.linspace(0, len(months), len(months))
    X1 = np.linspace(0, len(months) + 1, len(months) + 1)
    for i in range(len(psi_array)):
        plt.bar(X - (1/float(len(psi_array)))*i, psi_array[i], width=1/float(len(psi_array)), label=labels_array[i],
                zorder=3)
    #plt.bar(X, psi2,  width=0.5, color='r', label=label2, zorder=3)
    plt.plot(X1, [0.1]*(len(X) + 1), 'black')
    plt.plot(X1, [0.25]*(len(X) + 1), 'r')

    plt.title(title, fontsize=18)
    plt.xticks(X, months, rotation=45)
    plt.xlim(0, len(months)+0.5)
    plt.ylim(0, 0.3)
    plt.xlabel('Months', fontsize=13)
    plt.ylabel('PSI', fontsize=13)
    plt.legend()



def psi_hist(data, scores, months, month_col, pivot=0, score_names=None, title="PSI", bins=10):
    """
    data: pandas dataframe
        must contain columns for every score from scores and months_col column
    scores: array like
        array of score names in data dataframe for which psi will be calculated
    months: array like
        months for which psi is calculated
    months_col: string
        name of the column in data dataframe which contains month for each row
    score_names: array of strings, optional, default None
        labels for histogram, if None then index number of score will be used as label
    title: string, optional
        title of the histogram
    """
    
    psi_results = []
    for s in scores:
        psi_s = []
        x = data.loc[(data[month_col] == months[pivot]) &
                     (data[s].notnull()), s]
        for m in months:
            y = data.loc[(data[month_col] == m) &
                         (data[s].notnull()), s]
            psi_s.append(psi(x, y, bins=bins))
        psi_results.append(psi_s)
    if not score_names:
        score_names = range(len(scores))
    psi_comparison_chart(months, psi_results, score_names, title)
    




