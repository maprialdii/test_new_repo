"""
Home Credit Python Scoring Library and Workflow
Copyright © 2017-2019, Pavel Sůva, Marek Teller, Martin Kotek, Jan Zeller, 
Marek Mukenšnabl, Kirill Odintsov, Elena Kuchina, Jan Coufalík, Jan Hynek and
Home Credit & Finance Bank Limited Liability Company, Moscow, Russia.
All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import pandas as pd
import numpy as np
from sklearn.metrics import roc_auc_score
from sklearn.linear_model import LogisticRegression, LogisticRegressionCV
from sklearn.base import BaseEstimator, RegressorMixin
from sklearn.utils.validation import check_is_fitted
from sklearn.svm import l1_min_c
from sklearn.model_selection import cross_val_score, KFold
from tqdm.notebook import tqdm
import matplotlib.pyplot as plt
from IPython.display import display
import sklearn.linear_model
import sklearn.metrics
import math
from concurrent.futures import ThreadPoolExecutor


class GiniStepwiseLogit(BaseEstimator, RegressorMixin):
    def __init__(
        self,
        initial_predictors=set(),
        max_iter=1000,
        min_increase=0.5,
        max_decrease=0.25,
        max_predictors=0,
        max_correlation=1,
        beta_sgn_criterion=False,
        penalty="l2",
        C=10e10,
        correlation_sample=10000,
        selection_method="stepwise",
        use_cv=False,
        cv_folds=5,
        cv_seed=98765,
        n_jobs=1,
    ):
        # initiation of the instance

        # set of initial predictors for the first iteration. Can be empty.
        self.initial_predictors = initial_predictors
        # maximal number of iterations (forward and backward step of stepwise regression is considered one iteration)
        self.max_iter = max_iter
        # minimal gini increase for forward step (if predictor adds lower increment than this, it should not be added)
        self.min_increase = min_increase
        # maximal gini decrease for backward step (if predictor lowers gini by more than this, it should not be taken away)
        self.max_decrease = max_decrease
        # maximal number of predictors in model (if exceeded, no forward steps are considered). If set to 0, then ignored.
        self.max_predictors = max_predictors
        # maximal abs.value of correlation of two predictors inside the model (models where a couple of predictors exceeds
        # this correlation are not consdered). If set to 1 or above, then ignored.
        self.max_correlation = max_correlation
        # if set to True, than only models where all betas (except intercept) have the same signum are considered.
        self.beta_sgn_criterion = beta_sgn_criterion
        # type of penalty in logistic regression ('l1' for L1, 'l2' for L2)
        self.penalty = penalty
        # inverse of L1/L2 penalty for the logistic regression (by default: set to very high so the penalty is very low)
        self.C = C
        # when the correlation matrix is calculated, how big rows sample should be used for that
        self.correlation_sample = correlation_sample
        # selection method ('stepwise','forward','backward')
        self.selection_method = selection_method
        # cross validation - boolean if to use it
        self.use_cv = use_cv
        # cross validation folds - number
        self.cv_folds = cv_folds
        # cross validation folds - random seed for shuffling
        self.cv_seed = cv_seed
        self.n_jobs = n_jobs

    def __cros_val_auc(self, X, y, weights=None):
        # performs crossvalidation training and calculates average (cross)validation Gini

        # convert pandas structures to numpy structures
        X = X.values
        y = y.values
        if weights is not None:
            weights = weights.values

        # stratified k-fold
        kf = KFold(n_splits=self.cv_folds, shuffle=True, random_state=self.cv_seed)
        kf.get_n_splits(X)

        aucs = []

        for train_index, test_index in kf.split(X):

            newModel = LogisticRegression(
                penalty=self.penalty, C=self.C, solver="liblinear"
            )

            # train/test split
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]

            if weights is not None:
                weights_train, weights_test = weights[train_index], weights[test_index]
                newModel.fit(X_train, y_train, sample_weight=weights_train)
                y_pred = newModel.predict_proba(X_test)[:, 1]
                auc = roc_auc_score(y_test, y_pred, sample_weight=weights_test)

            else:
                newModel.fit(X_train, y_train)
                y_pred = newModel.predict_proba(X_test)[:, 1]
                auc = roc_auc_score(y_test, y_pred)

            # evaluate score metric
            aucs.append(auc)

        avg_auc = sum(aucs) / len(aucs)

        return avg_auc

    def __one_model(
        self, X, y, X_valid, y_valid, sample_weight=None, sample_weight_valid=None
    ):
        # calculates a regression model on the given set and with given parameters
        # returns its gini and indicator whether the betas have the same signum

        # train model using training sample
        # this must be done even for Cross Validation !!!
        # the reason is: criteria as same beta signum must be evaluated on one firm set of coefficients
        newModel = LogisticRegression(
            penalty=self.penalty, C=self.C, solver="liblinear"
        )
        # if there is a variable with weights, use weighted regression
        if sample_weight is None:
            newModel.fit(X, y)
        else:
            newModel.fit(X, y, sample_weight)

        # without Cross Validation
        if not (self.use_cv):
            # measure Gini of such model
            predictions = newModel.predict_proba(X_valid)[:, 1]
            if sample_weight_valid is None:
                gini_result = 200 * roc_auc_score(y_valid, predictions) - 100
            else:
                gini_result = (
                    200
                    * roc_auc_score(
                        y_valid, predictions, sample_weight=sample_weight_valid
                    )
                    - 100
                )

        # with Cross Validation
        else:
            # the weight is None codition is resolved inside the called function
            cv_auc = self.__cros_val_auc(X, y, sample_weight)
            gini_result = 200 * cv_auc - 100

        # sum of absolute values of beta is the same as absolute value of sum of beta
        # which occurs if and only if all the betas have the same signum
        if sum(sum(abs(newModel.coef_))) == abs(sum(sum(newModel.coef_))):
            same_beta_sgn = True
        else:
            same_beta_sgn = False

        return gini_result, same_beta_sgn

    def __max_abs_corr(self, cormat, predictors):
        # returns maximum absolute correlation in the given set of predictors

        # correlation submatrix for predictor set given by the model
        subcormat = cormat[list(predictors)].loc[list(predictors)]

        # set diagonal values to 0 (as the original 1 should not enter the maximum calculation)
        np.fill_diagonal(subcormat.values, 0)

        # calculates absolute value of the correlations (we are interested in both negative and positive correlations)
        # then finds the greatest of these values
        max_corr = abs(subcormat).values.max()

        return max_corr

    def __find_same_model(self, predictor_set, allModels):
        # determine whether there is already model with given predictors set in allModels

        # if such model was calculated before, use numbers from the previous calculation
        same_model_list = list(
            filter(lambda model: model["predictors"] == predictor_set, allModels)
        )

        # number of same models already calculated
        same_model_count = len(same_model_list)

        # assign values from the first same model or empty values
        if same_model_count > 0:
            gini_result = same_model_list[0]["Gini"]
            used_before = same_model_list[0]["used"]
            max_corr = same_model_list[0]["maxCorr"]
            same_beta_sgn = same_model_list[0]["betaSgn"]
        else:
            gini_result = None
            used_before = None
            max_corr = None
            same_beta_sgn = None

        return same_model_count, gini_result, used_before, max_corr, same_beta_sgn

    def __filter_possible_models(self, iterNum, allModels, incdec):
        # filter models which are feasible based on given criteria

        if incdec == "inc":
            # filter models that meet criteria: was not used before, Gini increment >= min_increase
            possibleModels = list(
                filter(
                    lambda model: model["iteration"] == iterNum
                    and model["addrm"] == 1
                    and model["used"] == 0
                    and model["diff"] >= self.min_increase,
                    allModels,
                )
            )

        elif incdec == "dec":
            # filter models that meet criteria: was not used before, Gini decrease <= max_decrease
            possibleModels = list(
                filter(
                    lambda model: model["iteration"] == iterNum
                    and model["addrm"] == -1
                    and model["used"] == 0
                    and model["diff"] >= -self.max_decrease,
                    allModels,
                )
            )

        else:
            possibleModels = allModels

        # additional filtering in case we want all betas to have the same signum
        if self.beta_sgn_criterion:
            possibleModels = list(
                filter(lambda model: model["betaSgn"] == True, possibleModels)
            )

        # additional filtering in case we have a condition for maximum correlation
        if self.max_correlation < 1 and self.max_correlation >= 0:
            possibleModels = list(
                filter(
                    lambda model: model["maxCorr"] <= self.max_correlation,
                    possibleModels,
                )
            )

        # order such models by added Gini desc
        possibleModels = sorted(possibleModels, key=lambda d: d["diff"], reverse=True)

        # if there is such model used flag must be updated
        if len(possibleModels) > 0:
            toUpdateModels = list(
                filter(
                    lambda model: model["predictors"]
                    == possibleModels[0]["predictors"],
                    allModels,
                )
            )
            toUpdateModels = [m.update({"used": 1}) for m in toUpdateModels]

        return possibleModels, allModels

    def fit(
        self,
        X,
        y,
        X_valid=None,
        y_valid=None,
        sample_weight=None,
        sample_weight_valid=None,
    ):
        """fit regression model while iterating in stepwise/forward/backward way
            
            Arguments:
                X {pd.DataFrame} -- df with predictors - training sample
                y {pd.Series} -- target - training sample
            
            Keyword Arguments:
                X_valid {pd.DataFrame} -- df with predictors - validation sample. if unspecified, training sample is used for validation. if use_cv = True in object initialization, both train and validation sample are used for cv folds. (default: {None})
                y_valid {pd.Series} -- target - validation sample. if unspecified, training sample is used for validation. if use_cv = True in object initialization, both train and validation sample are used for cv folds. (default: {None})
                sample_weight {pd.Series} -- obervarion weights - training sample. if unspecified, weights = 1 for each observation are used. (default: {None})
                sample_weight_valid {pd.Series} -- obervarion weights. if unspecified, weights = 1 for each observation are used. (default: {None})
        """


        if self.use_cv:
            if (X_valid is not None) or (y_valid is not None):
                print(
                    "Cross validation will be used for the union of training and validation sample."
                )
                print(
                    "If you want to use cross validation for training sample only, do not submit any validation sample."
                )
                X = pd.concat([X, X_valid])
                y = pd.concat([y, y_valid])
                X_valid = X
                y_valid = y
                if sample_weight is not None:
                    sample_weight = pd.concat(sample_weight, sample_weight_valid)
                else:
                    sample_weight = None
                sample_weight_valid = sample_weight
            else:
                print("Cross validation will be used for the training sample.")
                X_valid = X
                y_valid = y
                sample_weight_valid = sample_weight
        else:
            if (X_valid is not None) and (y_valid is not None):
                print(
                    "Regression will be trained using training sample, Gini will be evaluated using validation sample."
                )
            else:
                X_valid = X
                y_valid = y
                sample_weight_valid = sample_weight
                print(
                    "No validation sample submitted, Gini will be evaluated using training sample."
                )

        # define set with all possible predictors
        predictorVars = set(list(X))

        # make sure that min_increase > max_decrease >= 0 - otherwise there might be an infinite loop
        if self.max_decrease < 0:
            self.max_decrease = 0
            print("max_decrease parameter was invalid, it is set to 0 now.")
        if self.min_increase <= self.max_decrease:
            self.min_increase = self.max_decrease + 0.01
            print(
                "min_increase parameter was <= max_decrease, it is set to max_decrease+0.01 now"
            )

        if (self.selection_method != "forward") and (
            (self.max_correlation < 1) or (self.beta_sgn_criterion)
        ):
            self.beta_sgn_criterion = False
            self.max_correlation = 1
            print(
                'Beta signum criterion and max correlation will not be used as the selection method is not "forward"'
            )

        # correlation matrix of all the predictors, calculated on sample with size defined by a parameter
        rowsCount = len(X.index)
        # the correlation is calculated on a sample, however for small data use the whole dataset
        if rowsCount <= self.correlation_sample:
            cormat = X.corr()
        else:
            cormat = X.sample(self.correlation_sample).corr()

        # init variable consolidating stopping criteria
        stopNow = 0
        # init variable with current step number
        iterNum = 0
        # init set of currently used predictors
        modelID = 0

        # number of predictors in the initial set
        newPredNum = len(self.initial_predictors)
        newPredSet = self.initial_predictors

        # there are some predictors in the inital set, the create the initial model of it
        if newPredNum > 0:

            # logit regression
            newGini, betaSgn = self.__one_model(
                X[list(newPredSet)],
                y,
                X_valid[list(newPredSet)],
                y_valid,
                sample_weight,
                sample_weight_valid,
            )
            # maximum correlation between the predictors
            maxCorr = self.__max_abs_corr(cormat, newPredSet)

        # the inital set of predictors is empty, then the model has 0 Gini
        else:
            newGini = 0
            betaSgn = True
            maxCorr = 0

        # init data structure with all models so far
        # iteration number, add or remove, set of predictors, number of predictors, Gini, Gini difference, model used
        allModels = [
            {
                "ID": modelID,
                "iteration": 0,
                "addrm": 0,
                "predictors": newPredSet,
                "prednum": newPredNum,
                "Gini": newGini,
                "diff": 0,
                "used": 1,
                "betaSgn": betaSgn,
                "maxCorr": maxCorr,
            }
        ]

        # output to screen
        print()
        print(
            f"Iter    Gini    GiniΔ  #Pred   AddedPred                                RemovedPred"
        )
        print(
            f"[{iterNum:>2}]   {newGini:>5.2f}              {newPredNum:<5}{newPredSet}"
        )
        # print(f"Iteration {iterNum:<100}")
        # print(newPredSet)
        # print(f"Achieved Gini: {newGini:4.2f}")

        # go to step 1
        iterNum = iterNum + 1
        if iterNum > self.max_iter:
            stopNow = 1
            currentModel = allModels[0]

        # iterate until stopping criteria met
        while stopNow == 0:

            # find the model we want to tune
            originalModel = (
                list(
                    filter(
                        lambda model: model["iteration"] == iterNum - 1
                        and model["addrm"] == 0,
                        allModels,
                    )
                )
            )[0]

            # get the Gini of this model from the previous step
            currentModel = originalModel
            currentGini = currentModel["Gini"]
            addedPredictor = None
            removedPredictor = None

            # check whether current number of predictors == max_predictors parameter value
            if (
                (self.selection_method == "stepwise")
                or (self.selection_method == "forward")
            ) and (
                (currentModel["prednum"] < self.max_predictors)
                or (self.max_predictors <= 0)
            ):
                if self.n_jobs <= 1:
                    # we still can add more predictors
                    # iterate through all unused predictors
                    for newPredictor in predictorVars - currentModel["predictors"]:

                        # try model with addition of new predictor
                        result = self._add_predictors(
                            currentModel,
                            newPredictor,
                            allModels,
                            X,
                            y,
                            X_valid,
                            y_valid,
                            sample_weight,
                            sample_weight_valid,
                            cormat,
                            modelID,
                            iterNum,
                            newPredSet,
                            newGini,
                            currentGini,
                            betaSgn,
                            maxCorr,
                        )

                        allModels.append(result)
                else:


                    def add_predictors(newPredictor):
                        return self._add_predictors(
                            currentModel,
                            newPredictor,
                            allModels,
                            X,
                            y,
                            X_valid,
                            y_valid,
                            sample_weight,
                            sample_weight_valid,
                            cormat,
                            modelID,
                            iterNum,
                            newPredSet,
                            newGini,
                            currentGini,
                            betaSgn,
                            maxCorr,
                        )

                    with ThreadPoolExecutor(self.n_jobs) as p:
                        allModels += list(
                            p.map(
                                add_predictors,
                                predictorVars - currentModel["predictors"],
                            )
                        )
                # filter only models fulfilling criteria to be used
                possibleModels, allModels = self.__filter_possible_models(
                    iterNum, allModels, incdec="inc"
                )

                # if there is such model, set that the selected model is the current one
                if len(possibleModels) > 0:
                    currentModel = possibleModels[0]
                    currentGini = currentModel["Gini"]
                    addedPredictor = (
                        currentModel["predictors"] - originalModel["predictors"]
                    ).pop()

                # else the original model proceeds to the next step

            # if more than one predictor, try to remove one
            if (
                (self.selection_method == "stepwise")
                or (self.selection_method == "backward")
            ) and currentModel["prednum"] > 1:

                # iterate through all used predictors
                if self.n_jobs <= 1:
                    for remPredictor in currentModel["predictors"]:

                        # try model with removal of one predictor
                        result = self._remove_predictor(
                            currentModel,
                            remPredictor,
                            allModels,
                            X,
                            y,
                            X_valid,
                            y_valid,
                            sample_weight,
                            sample_weight_valid,
                            cormat,
                            modelID,
                            iterNum,
                            newPredSet,
                            newGini,
                            currentGini,
                            betaSgn,
                            maxCorr,
                        )
                        allModels.append(result)
                else:
                    with ThreadPoolExecutor(self.n_jobs) as p:
                        allModels += list(
                            p.map(
                                lambda remPredictor: self._remove_predictor(
                                    currentModel,
                                    remPredictor,
                                    allModels,
                                    X,
                                    y,
                                    X_valid,
                                    y_valid,
                                    sample_weight,
                                    sample_weight_valid,
                                    cormat,
                                    modelID,
                                    iterNum,
                                    newPredSet,
                                    newGini,
                                    currentGini,
                                    betaSgn,
                                    maxCorr,
                                ),
                                predictorVars - currentModel["predictors"],
                            )
                        )

                # filter only models fulfilling criteria to be used
                possibleModels, allModels = self.__filter_possible_models(
                    iterNum, allModels, incdec="dec"
                )

                # if there is such model, set that the selected model is the current one
                if len(possibleModels) > 0:
                    currentModel = possibleModels[0]
                    currentGini = currentModel["Gini"]
                    removedPredictor = (
                        originalModel["predictors"] - currentModel["predictors"]
                    ).pop()

                # else the original model proceeds to the next step

            # add the basic model for the next iteration to the data set
            modelID = modelID + 1
            allModels.append(
                {
                    "ID": modelID,
                    "iteration": iterNum,
                    "addrm": 0,
                    "predictors": currentModel["predictors"],
                    "prednum": currentModel["prednum"],
                    "Gini": currentModel["Gini"],
                    "diff": 0,
                    "used": 1,
                    "betaSgn": currentModel["betaSgn"],
                    "maxCorr": currentModel["maxCorr"],
                }
            )
            # output to screen
            changedGini = currentGini - originalModel["Gini"]

            print(
                f"[{iterNum:>2}]   {currentModel['Gini']:>5.2f}   {changedGini:>+6.2f}    {currentModel['prednum']:>2}    {addedPredictor if addedPredictor else '':<40} {removedPredictor if removedPredictor else ''}"
            )
            # print(f"Iteration {iterNum:<100}")
            # #output predictor list and Gini to screen
            # print(currentModel['predictors'])
            # print(f"Achieved Gini: {currentModel['Gini']:4.2f}")

            # new iteration number
            iterNum = iterNum + 1

            # if the model proceeding to the next iteration is the original model or maximal interation number achived, stop
            if (currentModel == originalModel) or (iterNum > self.max_iter):
                stopNow = 1

        # output attributes creation
        # set data frame with all iterations
        self.model_progress_ = pd.DataFrame.from_records(allModels)

        # set final model description
        self.final_predictors_ = list(currentModel["predictors"])

        # fits the final model
        self.final_model_ = LogisticRegression(
            penalty=self.penalty, C=self.C, solver="liblinear"
        )
        if sample_weight is None:
            self.final_model_.fit(X[self.final_predictors_], y)
        else:
            self.final_model_.fit(X[self.final_predictors_], y, sample_weight)

        self.coef_ = self.final_model_.coef_
        self.intercept_ = self.final_model_.intercept_

        return self

    def _remove_predictor(
        self,
        currentModel,
        remPredictor,
        allModels,
        X,
        y,
        X_valid,
        y_valid,
        sample_weight,
        sample_weight_valid,
        cormat,
        modelID,
        iterNum,
        newPredSet,
        newGini,
        currentGini,
        betaSgn,
        maxCorr,
    ):
        # try model with removal of one predictor
        newPredSet = currentModel["predictors"] - {remPredictor}

        # if such model was calculated before, use numbers from the previous calculation
        sameModelCnt, newGini, usedBefore, maxCorr, betaSgn = self.__find_same_model(
            newPredSet, allModels
        )

        # else calculate the model now
        if sameModelCnt < 1:
            # logit regression - use special function
            newGini, betaSgn = self.__one_model(
                X[list(newPredSet)],
                y,
                X_valid[list(newPredSet)],
                y_valid,
                sample_weight,
                sample_weight_valid,
            )
            # maximum correlation between the predictors
            maxCorr = self.__max_abs_corr(cormat, newPredSet)
            usedBefore = 0

        # add to data structure
        # modelID = modelID + 1
        result = {
            "ID": modelID,
            "iteration": iterNum,
            "addrm": -1,
            "predictors": newPredSet,
            "prednum": len(newPredSet),
            "Gini": newGini,
            "diff": newGini - currentGini,
            "used": usedBefore,
            "betaSgn": betaSgn,
            "maxCorr": maxCorr,
        }
        return result

    def _add_predictors(
        self,
        currentModel,
        newPredictor,
        allModels,
        X,
        y,
        X_valid,
        y_valid,
        sample_weight,
        sample_weight_valid,
        cormat,
        modelID,
        iterNum,
        newPredSet,
        newGini,
        currentGini,
        betaSgn,
        maxCorr,
    ):
        # try model with addition of new predictor
        newPredSet = currentModel["predictors"] | {newPredictor}

        # if such model was calculated before, use numbers from the previous calculation
        sameModelCnt, newGini, usedBefore, maxCorr, betaSgn = self.__find_same_model(
            newPredSet, allModels
        )

        # else calculate the model now
        if sameModelCnt < 1:
            # logit regression - use special function
            newGini, betaSgn = self.__one_model(
                X[list(newPredSet)],
                y,
                X_valid[list(newPredSet)],
                y_valid,
                sample_weight,
                sample_weight_valid,
            )
            # maximum correlation between the predictors
            maxCorr = self.__max_abs_corr(cormat, newPredSet)
            usedBefore = 0

        # add to data structure
        modelID = modelID + 1
        result = {
            "ID": modelID,
            "iteration": iterNum,
            "addrm": 1,
            "predictors": newPredSet,
            "prednum": len(newPredSet),
            "Gini": newGini,
            "diff": newGini - currentGini,
            "used": usedBefore,
            "betaSgn": betaSgn,
            "maxCorr": maxCorr,
        }
        return result

    def predict(self, X):
        # uses the fitted final model to calculate predictions

        check_is_fitted(self, ["model_progress_", "final_predictors_", "final_model_"])

        # calculates the predicted probabilities
        y = self.final_model_.predict_proba(X[self.final_predictors_])[:, 1]

        return y

    def draw_gini_progression(self, output_file=None):
        """Draws progression plot of gini values during step-wise fitting.

        Plots values of gini based on step during step-wise fitting of model.

        Args:
            output_file (str, optional): relative path to file to export

        Returns:
            None
            Draws a plot with mathplotlib to notebook. 

        """
        it = range(
            0, len(self.model_progress_[self.model_progress_["addrm"] == 0]["prednum"])
        )
        pn = self.model_progress_[self.model_progress_["addrm"] == 0]["prednum"]
        ginis = self.model_progress_[self.model_progress_["addrm"] == 0]["Gini"]
        plt.figure(figsize=(7, 7))
        plt.plot(it, ginis)
        ymin, ymax = plt.ylim()
        plt.xlabel("Iteration")
        plt.ylabel("Gini")
        plt.title("Stepwise model selection")
        plt.axis("tight")
        if output_file is not None:
            plt.savefig(output_file, bbox_inches="tight", dpi=72)
        plt.show()
        plt.clf()
        plt.close()


class L1GiniModelSelection:
    def __init__(
        self,
        steps=50,
        grid_length=5,
        log_C_init=None,
        max_predictors=20,
        max_correlation=1,
        beta_sgn_criterion=False,
        stop_immediately=False,
        stop_when_decr=False,
        correlation_sample=10000,
        penalty="l1",
        use_cv=False,
        cv_folds=5,
        cv_seed=98765,
    ):

        # number of iterations for L1 C parameter grid search
        self.steps = steps
        self.max_predictors = max_predictors
        self.max_correlation = max_correlation
        self.beta_sgn_criterion = beta_sgn_criterion
        self.correlation_sample = correlation_sample
        self.grid_length = grid_length
        if log_C_init is not None:
            self.C_init = 10 ** log_C_init
        else:
            self.C_init = None
        self.stop_immediately = stop_immediately
        self.stop_when_decr = stop_when_decr
        self.penalty = penalty
        # cross validation - boolean if to use it
        self.use_cv = use_cv
        # cross validation folds - number
        self.cv_folds = cv_folds
        # cross validation folds - random seed for shuffling
        self.cv_seed = cv_seed

    def __cros_val_auc(self, X, y, weights=None, C=1):
        # performs crossvalidation training and calculates average (cross)validation Gini

        # convert pandas structures to numpy structures
        X = X.values
        y = y.values
        if weights is not None:
            weights = weights.values

        # stratified k-fold
        kf = KFold(n_splits=self.cv_folds, shuffle=True, random_state=self.cv_seed)
        kf.get_n_splits(X)

        aucs = []

        for train_index, test_index in kf.split(X):

            newModel = LogisticRegression(penalty=self.penalty, C=C, solver="liblinear")

            # train/test split
            X_train, X_test = X[train_index], X[test_index]
            y_train, y_test = y[train_index], y[test_index]

            if weights is not None:
                weights_train, weights_test = weights[train_index], weights[test_index]
                newModel.fit(X_train, y_train, sample_weight=weights_train)
                y_pred = newModel.predict_proba(X_test)[:, 1]
                auc = roc_auc_score(y_test, y_pred, sample_weight=weights_test)

            else:
                newModel.fit(X_train, y_train)
                y_pred = newModel.predict_proba(X_test)[:, 1]
                auc = roc_auc_score(y_test, y_pred)

            # evaluate score metric
            aucs.append(auc)

        avg_auc = sum(aucs) / len(aucs)

        return avg_auc

    def __max_abs_corr(self, cormat, predictors):
        # returns maximum absolute correlation in the given set of predictors

        # correlation submatrix for predictor set given by the model
        subcormat = cormat[list(predictors)].loc[list(predictors)]

        # set diagonal values to 0 (as the original 1 should not enter the maximum calculation)
        np.fill_diagonal(subcormat.values, 0)

        # calculates absolute value of the correlations (we are interested in both negative and positive correlations)
        # then finds the greatest of these values
        max_corr = abs(subcormat).values.max()

        return max_corr

    def fit(
        self,
        X,
        y,
        X_valid=None,
        y_valid=None,
        sample_weight=None,
        sample_weight_valid=None,
        progress_bar=False,
    ):

        if self.use_cv:
            if (X_valid is not None) or (y_valid is not None):
                print(
                    "Cross validation will be used for the union of training and validation sample."
                )
                print(
                    "If you want to use cross validation for training sample only, do not submit any validation sample."
                )
                X = pd.concat([X, X_valid])
                y = pd.concat([y, y_valid])
                X_valid = X
                y_valid = y
                if sample_weight is not None:
                    sample_weight = pd.concat(sample_weight, sample_weight_valid)
                else:
                    sample_weight = None
                sample_weight_valid = sample_weight
            else:
                print("Cross validation will be used for the training sample.")
                X_valid = X
                y_valid = y
                sample_weight_valid = sample_weight
        else:
            if (X_valid is not None) and (y_valid is not None):
                print(
                    "Regression will be trained using training sample, Gini will be evaluated using validation sample."
                )
            else:
                X_valid = X
                y_valid = y
                sample_weight_valid = sample_weight
                print(
                    "No validation sample submitted, Gini will be evaluated using training sample."
                )

        # correlation matrix of all the predictors, calculated on sample with size defined by a parameter
        rowsCount = len(X.index)
        # the correlation is calculated on a sample, however for small data use the whole dataset
        if rowsCount <= self.correlation_sample:
            cormat = X.corr()
        else:
            cormat = X.sample(self.correlation_sample).corr()
        # initial C parameter value
        if self.C_init is None:
            if self.penalty == "l2":
                loss_init = "squared_hinge"
            else:
                loss_init = "log"
            C_init = l1_min_c(X, y, loss=loss_init)
        else:
            C_init = self.C_init

        # grid for C parameter values
        cs = C_init * np.logspace(0, self.grid_length, num=self.steps)
        lr = LogisticRegression(C=1, penalty=self.penalty, solver="liblinear")

        allModels = []
        self.coefs_ = []
        self.intercepts_ = []

        iterNum = 0

        cont = True

        if progress_bar:
            iterator = tqdm(cs)
        else:
            iterator = cs

        gini_before = 0

        for c in iterator:

            # if stopping criteria were not met yet
            if cont:

                # fit regression in this iteration
                # this must be done even for Cross Valiation !!!
                # some criteria as same beta sign must be evaluated on one firm (final) set of coefficients which will be the set trained on full sample
                lr.set_params(C=c)
                # if there is a variable with weights, use weighted regression
                if sample_weight is None:
                    lr.fit(X, y)
                else:
                    lr.fit(X, y, sample_weight)

                # evaluate same-sign-beta and corr criteria
                coefs = lr.coef_.ravel().copy()
                intercepts = lr.intercept_
                coefs_nonzero = np.count_nonzero(coefs)
                coefs_samesign = abs(np.sum(coefs)) - np.sum(abs(coefs)) == 0
                predictors = set(X.columns[coefs != 0])
                if intercepts != 0:
                    predictors_w_intercept = predictors | {"Intercept"}
                else:
                    predictors_w_intercept = predictors
                if coefs_nonzero > 0:
                    max_corr = self.__max_abs_corr(cormat, predictors)
                else:
                    max_corr = 0

                # Gini caluclation is done separately for CV and nonCV case:

                # without Cross Validation
                if not (self.use_cv):

                    # calculate predictions
                    pred_train = lr.predict_proba(X)[:, 1]
                    pred_valid = lr.predict_proba(X_valid)[:, 1]

                    # calculate Gini coefficients
                    if sample_weight is None:
                        gini_train = 200 * roc_auc_score(y, pred_train) - 100
                    else:
                        gini_train = (
                            200
                            * roc_auc_score(y, pred_train, sample_weight=sample_weight)
                            - 100
                        )
                    if sample_weight_valid is None:
                        gini_valid = 200 * roc_auc_score(y_valid, pred_valid) - 100
                    else:
                        gini_valid = (
                            200
                            * roc_auc_score(
                                y_valid, pred_valid, sample_weight=sample_weight_valid
                            )
                            - 100
                        )

                # with Cross Validation
                else:
                    # measure Gini of such model
                    # the weight is None codition is resolved inside the called function
                    cv_auc = self.__cros_val_auc(X, y, sample_weight, C=c)
                    gini_valid = 200 * cv_auc - 100
                    gini_train = np.nan

                # evaluate meeting of stopping criteria

                if (
                    (
                        (coefs_nonzero <= self.max_predictors)
                        and (self.max_predictors > 0)
                    )
                    and ((self.beta_sgn_criterion == False) or (coefs_samesign == True))
                    and (max_corr <= self.max_correlation)
                ):

                    allModels.append(
                        {
                            "C": c,
                            "predictors": predictors,
                            "non-zero betas": coefs_nonzero,
                            "same signature of betas": coefs_samesign,
                            "max corr": max_corr,
                            "gini train": gini_train,
                            "gini validate": gini_valid,
                            "criteria passed": True,
                        }
                    )

                    print("Iteration", iterNum, "  log10(C) =", math.log10(c))
                    print(predictors_w_intercept)
                    print("Achieved Gini: ", gini_valid)

                    self.coefs_.append(coefs)
                    self.intercepts_.append(intercepts)

                else:

                    allModels.append(
                        {
                            "C": c,
                            "predictors": predictors,
                            "non-zero betas": coefs_nonzero,
                            "same signature of betas": coefs_samesign,
                            "max corr": max_corr,
                            "gini train": gini_train,
                            "gini validate": gini_valid,
                            "criteria passed": False,
                        }
                    )

                    print("Iteration", iterNum, "  log10(C) =", math.log10(c))
                    problems_str = ""
                    if not (
                        (coefs_nonzero <= self.max_predictors)
                        and (self.max_predictors > 0)
                    ):
                        problems_str = problems_str + " too many predictors,"
                    if (self.beta_sgn_criterion == True) and (coefs_samesign == False):
                        problems_str = problems_str + " betas with different signs,"
                    if max_corr > self.max_correlation:
                        problems_str = problems_str + " correlations too high,"
                    print("CRITERIA NOT FULFILLED:" + problems_str)
                    print(predictors_w_intercept)
                    print("Achieved Gini: ", gini_valid)

                    self.coefs_.append(coefs)
                    self.intercepts_.append(intercepts)

                    if self.stop_immediately:
                        cont = False

                if gini_before > gini_valid:

                    print("Gini decreased from previous step.")

                    if self.stop_when_decr:
                        cont = False

                gini_before = gini_valid

                iterNum = iterNum + 1

        # order models by added Gini desc
        possibleModels = list(
            filter(
                lambda model: model["non-zero betas"] > 0
                and model["criteria passed"] == True,
                allModels,
            )
        )
        sortedModels = sorted(
            possibleModels, key=lambda d: d["gini validate"], reverse=True
        )
        self.model_progress_ = pd.DataFrame.from_records(allModels)

        if len(possibleModels) > 0:
            self.C_ = sortedModels[0]["C"]
            self.final_predictors_ = list(sortedModels[0]["predictors"])

            self.final_model_ = LogisticRegression(
                penalty=self.penalty, C=self.C_, solver="liblinear"
            )

            if sample_weight is None:
                self.final_model_.fit(X[self.final_predictors_], y)
            else:
                self.final_model_.fit(X[self.final_predictors_], y, sample_weight)

            self.coef_ = self.final_model_.coef_
            self.intercept_ = self.final_model_.intercept_

    def predict(self, X):
        # uses the fitted final model to calculate predictions

        check_is_fitted(self, ["model_progress_", "final_predictors_", "final_model_"])

        # calculates the predicted probabilities
        y = self.final_model_.predict_proba(X[self.final_predictors_])[:, 1]

        return y

    def draw_coeff_progression(self, predictor_names, output_file=None):
        """Draws progression plot of coefficient values during L1 fitting.

        Plots values of ceofficients based on value of regularization parameter C.

        Args:
            predictors_names (list): names of predictors in order in which they were used during fitting
            output_file (str, optional): relative path to file to export

        Returns:
            None
            Draws a plot with mathplotlib to notebook. 

        """
        coefs_ = [
            [CC for CC in C] + [II for II in I]
            for C, I in zip(np.array(self.coefs_), np.array(self.intercepts_))
        ]
        cs = self.model_progress_["C"]
        plt.figure(figsize=(7, 7))
        plt.plot(np.log10(cs), coefs_)
        ymin, ymax = plt.ylim()
        plt.xlabel("log10(C)")
        plt.ylabel("Coefficients")
        plt.title("Logistic Regression Path")
        plt.axis("tight")
        plt.legend(
            predictor_names + ["Intercept"],
            loc="upper center",
            bbox_to_anchor=(1.4, 1.0),
        )
        if output_file is not None:
            plt.savefig(output_file, bbox_inches="tight", dpi=72)
        plt.show()
        plt.clf()
        plt.close()

    def draw_gini_progression(self, output_file=None):
        """Draws progression plot of gini values during L1 fitting.

        Plots values of gini based on value of regularization parameter C.

        Args:
            output_file (str, optional): relative path to file to export

        Returns:
            None
            Draws a plot with mathplotlib to notebook. 

        """
        plt.figure(figsize=(7, 7))
        ginis = self.model_progress_[["gini train", "gini validate"]]
        cs = self.model_progress_["C"]
        plt.plot(np.log10(cs), ginis)
        ymin, ymax = plt.ylim()
        plt.xlabel("log10(C)")
        plt.ylabel("Ginis")
        plt.title("Logistic Regression Path")
        plt.axis("tight")
        plt.legend(
            ["Train", "Validate"], loc="upper center", bbox_to_anchor=(1.20, 1.0)
        )
        if output_file is not None:
            plt.savefig(output_file, bbox_inches="tight", dpi=72)
        plt.show()
        plt.clf()
        plt.close()


class VarClusSurrogates(BaseEstimator, RegressorMixin):
    """
    Class for searching for surrogate variables for a finished regression model. When you have a model and you ran clustering analysis (from scoring.varclus module) on a superset of the model's predictors, you can try to swap each predictor with other variables from its cluster to see how the Gini would change.
    
    Args:
        variables (list of str): names of varibles from clustering output
        clusters (list of int): cluster numbers of the varibles (list must have same length as variables list) from the clustering output
        predictors (list of str): list of predictors of the original model
        
    Kwargs:
        penalty (str): 'l1' or 'l2' - penalization type of the regularized regression
        C (float): the larger C is, the weaker is the penalization of the regularized regression
        
    Properties:
        model_progress_ (pandas data frame): Created by fit() method. Table with all surrogates and information how usage of each surrogate would affect gini of the final model
        
    Example calling:
        vcs = VarClusSurrogates(km.variables_, km.labels_, modelSW.final_predictors_)
        vcs.fit(data[train_mask], data[train_mask][col_target], data[valid_mask], data[valid_mask][col_target])
        vcs.displaySurrogates(output_file = output_folder+'/predictors/predictor_surrogates.csv')
    """

    def __init__(self, variables, clusters, predictors, penalty="l2", C=10e10):
        """
        Initialization method. See args and kwargs definitions of the class.
        """
        self.variables = variables
        self.clusters = clusters
        self.predictors = predictors
        self.penalty = penalty
        self.C = C
        return

    def __one_model(
        self, X, y, X_valid, y_valid, sample_weight=None, sample_weight_valid=None
    ):
        """
        Calculates a regression model on the given set and with given parameters. Returns its gini and indicator whether the betas have the same signum.
        
        Args:
            X (dataframe or matrix): training set of predictors
            y (array): training array of target
            X_valid (dataframe or matrix): validation set of predictors (used for Gini measurement)
            y_valid (array): validation array of target (used for Gini measurement)
        
        Kwargs:
            sample_weight (array): weights of training observations
            sample_weight_valid (array): weights of validation observations
        """

        newModel = LogisticRegression(
            penalty=self.penalty, C=self.C, solver="liblinear"
        )

        # if there is a variable with weights, use weighted regression
        if sample_weight is None:
            newModel.fit(X, y)
        else:
            newModel.fit(X, y, sample_weight)

        # measure Gini of such model
        predictions = newModel.predict_proba(X_valid)[:, 1]
        if sample_weight_valid is None:
            gini_result = 200 * roc_auc_score(y_valid, predictions) - 100
        else:
            gini_result = (
                200
                * roc_auc_score(y_valid, predictions, sample_weight=sample_weight_valid)
                - 100
            )

        return gini_result

    def fit(
        self,
        X,
        y,
        X_valid=None,
        y_valid=None,
        sample_weight=None,
        sample_weight_valid=None,
    ):
        """
        Calculates all possible regression models. The algorithm works as follows:
            For each predictor, find out in which cluster it is
                For each variable from the same cluster, fit model and calculate its Gini
                Sort the models by Gini
            Create table with all the steps, where in each row user can see how the Gini would change if one of the predictors is changed to one of its surrogates
        
        Args:
            X (dataframe or matrix): training set of predictors
            y (array): training array of target
            X_valid (dataframe or matrix): validation set of predictors (used for Gini measurement)
            y_valid (array): validation array of target (used for Gini measurement)
        
        Kwargs:
            sample_weight (array): weights of training observations
            sample_weight_valid (array): weights of validation observations
        """

        variables_count = len(self.variables)
        allModels = []

        # if there is no validation sample, then Gini will be calculated on the training sample
        if (X_valid is None) or (y_valid is None):
            X_valid = X
            y_valid = y
            sample_weight_valid = sample_weight

        # for each predictor, we will try to replace it with its surrogates
        for pred in self.predictors:
            if pred in self.variables:

                # Find surrogates in variables list
                print("Finding surrogates for predictor", pred, "...")
                idx = self.variables.index(pred)
                cl = self.clusters[idx]
                indices = [i for i, e in enumerate(self.clusters) if e == cl]
                surrogates = [self.variables[i] for i in indices]

                # for each surrogate, estimate a model, measure its gini
                for s in surrogates:
                    new_predictors = [p for p in self.predictors if p != pred]
                    new_predictors.append(s)
                    gini = self.__one_model(
                        X[new_predictors],
                        y,
                        X_valid[new_predictors],
                        y_valid,
                        sample_weight,
                        sample_weight_valid,
                    )

                    if pred == s:
                        flag_original = 1
                    else:
                        flag_original = 0

                    # append measured data into internal data structure
                    allModels.append(
                        {
                            "Original predictor": pred,
                            "Surrogate predictor": s,
                            "Gini": gini,
                            "Flag original": flag_original,
                        }
                    )

            else:
                print("Predictor", pred, "was not found in variables list.")

        # create data frame from internal data structure
        self.model_progress_ = pd.DataFrame.from_records(allModels)
        reference = self.model_progress_[self.model_progress_["Flag original"] == 1][
            ["Original predictor", "Gini"]
        ]
        self.model_progress_ = pd.merge(
            self.model_progress_,
            reference,
            left_on="Original predictor",
            right_on="Original predictor",
            suffixes=("", " Reference"),
        )
        self.model_progress_["Gini Difference"] = (
            self.model_progress_["Gini"] - self.model_progress_["Gini Reference"]
        )
        self.model_progress_ = self.model_progress_.sort_values(
            ["Original predictor", "Gini Difference"], ascending=[True, False]
        )[["Original predictor", "Surrogate predictor", "Gini", "Gini Difference"]]

        print("Finished. Use method displaySurrogates() to view the results.")
        return

    def displaySurrogates(self, output_file=None):
        """
        Displays table (data frame) with surrogates: In each row, there is name of original predictor, name of its surrogate and Gini delta. Gini delta = how Gini would change if instead of the predictor, surrogate variable is used.
        
        Kwargs:
            output_file (str): filename where dataframe is saved to as csv file.
        """

        check_is_fitted(self, ["model_progress_"])
        display(self.model_progress_)
        if output_file is not None:
            self.model_progress_.to_csv(output_file, index=False)
        return


class BootstrapLogit(BaseEstimator, RegressorMixin):
    """
    Model selection using bootstrapping. Wraps GiniStepwiseLogit or L1GiniModelSelection object and uses it to train multiple models on samples generated by bootstrapping. Averages the models at the end.
    """

    def __init__(
        self,
        base_model,
        bootstrap_samples=10,
        bootstrap_sample_size=1.0,
        random_seed=98765,
    ):
        """
        Initializes BootstrapLogit instance. Must be given existing instance of GiniStepwiseLogit or L1GiniModelSelection.
        
        Arguments:
            base_model {GiniStepwiseLogit or L1GiniModelSelection} -- existing instance of model selection class with chosen parameters
        
        Keyword Arguments:
            bootstrap_samples {int} -- How many time bootstrapping sample selection should be performed, i.e. how many models should be trained and averaged (default: {10})
            bootstrap_sample_size {float} -- Sample size in each bootstrap iteration (1=full data) (default: {1})
            random_seed {int} -- Random seed for replicable results (default: {98765})
        """

        self.base_model = base_model
        self.bootstrap_samples = bootstrap_samples
        self.bootstrap_sample_size = bootstrap_sample_size
        self.seeds = np.arange(10000 + 2 * self.bootstrap_samples)
        np.random.seed(random_seed)
        np.random.shuffle(self.seeds)

    def __avg_coefs(self, models):
        """
        Averages coefficients from models trained in all the bootstrap iterations.
        
        Arguments:
            models {list of dictionaries} -- list created in self.fit() method
        
        Returns:
            list, list, float -- ordered list of predictors in final (average) model, ordered list of corresponding final regression coefficients, intercept of final regression model
        """

        coef_df = pd.DataFrame(models)
        coef_df.fillna(0)
        final_predictors_ = []
        coef_ = []
        for col in coef_df.columns:
            if col != "INTERCEPT_":
                final_predictors_.append(col)
                coef_.append(coef_df[col].mean())
            else:
                intercept_ = coef_df[col].mean()
        return final_predictors_, coef_, intercept_

    def fit(
        self,
        X,
        y,
        X_valid=None,
        y_valid=None,
        sample_weight=None,
        sample_weight_valid=None,
    ):
        """
        Iterates bootstrapping. Trains a model in each iteration. Averages the models at the end.
        
        Arguments:
            X {pd.DataFrame} -- training data set with named predictors. This set will be used to estimate the regression coefficients.
            y {pd.Series} -- training series of target (indexes should correspond to X)
        
        Keyword Arguments:
            X_valid {pd.DataFrame} -- validation data set with named predictors. This set will be used to measure Gini select the variables into models. If None, training data set will be used. (default: {None})
            y_valid {pd.Series} -- validation series of target (indexes should correspond to X_valid) (default: {None})
            sample_weight {pd.Series} -- weights of observations in X (if None, all observations have weight 1) (default: {None})
            sample_weight_valid {pd.Series} -- weights of observations in X_valid (if None, all observations have weight 1) (default: {None})
        """

        models = []

        for i in range(self.bootstrap_samples):

            print("Bootstrap round", i)

            X_sampled = X.sample(
                frac=self.bootstrap_sample_size,
                random_state=self.seeds[i],
                replace=True,
            )
            y_sampled = y.sample(
                frac=self.bootstrap_sample_size,
                random_state=self.seeds[i],
                replace=True,
            )
            if sample_weight is not None:
                sample_weight_sampled = sample_weight.sample(
                    frac=self.bootstrap_sample_size, random_state=self.seeds[i]
                )
            else:
                sample_weight_sampled = None
            if X_valid is not None:
                X_valid_sampled = X_valid.sample(
                    frac=self.bootstrap_sample_size,
                    random_state=self.seeds[self.bootstrap_samples + i],
                )
            else:
                X_valid_sampled = None
            if y_valid is not None:
                y_valid_sampled = y_valid.sample(
                    frac=self.bootstrap_sample_size,
                    random_state=self.seeds[self.bootstrap_samples + i],
                )
            else:
                y_valid_sampled = None
            if sample_weight_valid is not None:
                sample_weight_valid_sampled = sample_weight_valid.sample(
                    frac=self.bootstrap_sample_size,
                    random_state=self.seeds[self.bootstrap_samples + i],
                )
            else:
                sample_weight_valid_sampled = None

            self.base_model.fit(
                X_sampled,
                y_sampled,
                X_valid_sampled,
                y_valid_sampled,
                sample_weight_sampled,
                sample_weight_valid_sampled,
            )

            coef_dict = dict(
                zip(
                    self.base_model.final_predictors_, self.base_model.coef_.tolist()[0]
                )
            )
            coef_dict["INTERCEPT_"] = self.base_model.intercept_[0]
            models.append(coef_dict)

        self.final_predictors_, self.coef_, self.intercept_ = self.__avg_coefs(models)

        self.final_model_ = LogisticRegression(
            penalty=self.base_model.penalty, C=self.base_model.C, solver="liblinear"
        )
        self.final_model_.fit(X[self.final_predictors_], y)
        self.final_model_.coef_ = np.array([self.coef_])
        self.final_model_.intercept_ = np.array([self.intercept_])

    def predict(self, X):
        """
        Based on values of predictors, it calculates prediction (score).
        
        Arguments:
            X {pd.DataFrame} -- dataset the prediction should be performed on. Must contain all the predictors which are contained in the fitted model.

        Returns:
            pd.Series -- prediction: probablity(target==1)
        """

        check_is_fitted(self, ["final_predictors_", "final_model_"])
        y = self.final_model_.predict_proba(X[self.final_predictors_])[:, 1]

        return y
