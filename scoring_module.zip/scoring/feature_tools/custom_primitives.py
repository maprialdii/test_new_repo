#%%
import featuretools as ft
import pandas as pd
import numpy as np


CURRENT_FUNCTIONS = dict(
    max=np.nanmax,
    min=np.nanmin,
    mean=np.nanmean,
    sum=np.nansum,
    count=len,
    mean_monthly=lambda x: np.nanmean(x) / 12,
)


def agg_last_x_days(values, time_col, days, func, time=None):
    """
    Aggregate given data using prespecified aggregation functions.
    Possibilities are set in CURRENT_FUNCTIONS
    
    """
    data = values[
        time_col.values >= np.datetime64(time - np.timedelta64(days, "D"))
    ].values

    # only floats can have infinities
    if data.dtype.kind == "f":
        # we need to remove infinities before aggregation to be consistent with oracle
        data[np.isinf(data)] = np.nan

    try:
        result = CURRENT_FUNCTIONS[func](data)
    except ValueError:
        result = None
    except KeyError:
        raise KeyError("Unidentified aggregation function as parameter 'func'")
    return result


def agg_last_x_days_generate_name(self, child_entity_id, base_feature_names, **kwargs):
    # print(self.kwargs)]})"
    name = "{func}_{days}D({child_entity_id}.{feature}{where_string})".format(
        func=self.kwargs["func"].upper(),
        days=str(self.kwargs["days"]),
        child_entity_id=child_entity_id,
        feature=base_feature_names[0],
        where_string=kwargs["where_str"],
    )
    return name


AGG_LAST_X_DAYS = ft.primitives.make_agg_primitive(
    function=agg_last_x_days,  # function to be used
    input_types=[
        ft.variable_types.Numeric,
        ft.variable_types.DatetimeTimeIndex,
    ],  # input data types
    return_type=ft.variable_types.Numeric,  # data types to be returned
    uses_calc_time=True,  # whether function can utilize cutoff time information
    stack_on_self=False,  # whether the primitive could be stacked on itself
    cls_attributes={
        "generate_name": agg_last_x_days_generate_name
    },  # passing of name generating function
)


def time_since_last(values, time=None, days=None):
    if days:
        values = values.values[
            values.values >= np.datetime64(time - np.timedelta64(days, "D"))
        ]
    if values:
        time_since = time - values.sort_values().iloc[0]
        return time_since.total_seconds()
    return None


def time_since_last_generate_name(self, child_entity_id, base_feature_names, **kwargs):
    print(self.kwargs)
    if self.kwargs["days"]:
        days = f"_{days}D"
    else:
        days = ""
    name = f"TIME_SINCE_LAST{days}({child_entity_id}.{base_feature_names[0]}{kwargs['where_str']})"
    return name


TIME_SINCE_LAST = ft.primitives.make_agg_primitive(
    function=time_since_last,
    input_types=[ft.variable_types.DatetimeTimeIndex],
    return_type=ft.variable_types.Numeric,
    uses_calc_time=True,
    name="time_since_last2",
    cls_attributes={"generate_name": time_since_last_generate_name},
)


def time_since_first(values, time=None, days=None):
    if days is not None:
        values = values[values >= np.datetime64(time - np.timedelta64(days, "D"))]
    if values.shape[0] == 0:
        return None
    time_since = time - values.sort_values().iloc[-1]
    return time_since.total_seconds()


def time_since_first_generate_name(self, child_entity_id, base_feature_names, **kwargs):
    if self.kwargs["days"]:
        days = f"_{days}D"
    else:
        days = ""
    name = f"TIME_SINCE_FIRST{days}({child_entity_id}.{base_feature_names[0]}{kwargs['where_str']})"
    return name


TIME_SINCE_FIRST = ft.primitives.make_agg_primitive(
    function=time_since_first,
    input_types=[ft.variable_types.DatetimeTimeIndex],
    return_type=ft.variable_types.Numeric,
    uses_calc_time=True,
    name="time_since_first",
    cls_attributes={"generate_name": time_since_first_generate_name},
)


def avg_time_between(values, time=None, days=None):
    if days is not None:
        values = values.values[
            values.values >= np.datetime64(time - np.timedelta64(days, "D"))
        ]
    if len(values) < 2:
        return None
    values = values.sort_values()
    values.name = "dtime"
    t = values[1:].reset_index() - values[:-1].reset_index()
    return t.mean()["dtime"].total_seconds()


def avg_time_between_generate_name(self, child_entity_id, base_feature_names, **kwargs):
    days = self.kwargs["days"]
    if self.kwargs["days"] is None:
        days = ""
    else:
        days = "_" + str(self.kwargs["days"]) + "D"
    name = f"AVG_TIME_BETWEEN{days}({child_entity_id}.{base_feature_names[0]}{kwargs['where_str']})"
    return name


AVG_TIME_BETWEEN = ft.primitives.make_agg_primitive(
    function=avg_time_between,
    input_types=[ft.variable_types.DatetimeTimeIndex],
    return_type=ft.variable_types.Numeric,
    uses_calc_time=True,
    name="avg_time_between2",
    cls_attributes={"generate_name": avg_time_between_generate_name},
)


def count_x_days(index, time_col, days, time=None):
    df = pd.DataFrame({"index": index, "time": time_col})
    df = df[df["time"] > time - ft.Timedelta(days, "d")]
    return df.shape[0]


def count_x_days_generate_name(self, child_entity_id, base_feature_names, **kwargs):
    # print(self.kwargs)
    name = f"{'COUNT'}_{str(self.kwargs['days'])}D({child_entity_id}.{base_feature_names[0]}{kwargs['where_str']})"
    return name


COUNT_X_DAYS = ft.primitives.make_agg_primitive(
    function=count_x_days,
    input_types=[ft.variable_types.Index, ft.variable_types.DatetimeTimeIndex],
    return_type=ft.variable_types.Numeric,
    uses_calc_time=True,
    name="count_x",
    cls_attributes={"generate_name": count_x_days_generate_name},
)


def multiple_agg_last_x_days(values, time_col, days, time=None):
    """
    Aggregate given data using prespecified aggregation functions.
    Possibilities are set in CURRENT_FUNCTIONS
    
    """
    data = values[
        time_col.values >= np.datetime64(time - np.timedelta64(days, "D"))
    ].values

    # only floats can have infinities
    if data.dtype.kind == "f":
        # we need to remove infinities before aggregation to be consistent with oracle
        data[np.isinf(data)] = np.nan
    result = []
    try:
        for function in CURRENT_FUNCTIONS.values():
            result += [function(data)]
    except ValueError:
        result = [None] * len(CURRENT_FUNCTIONS)
    return result


def multiple_agg_last_x_days_generate_name(
    self, child_entity_id, base_feature_names, **kwargs
):
    names = [
        "{func}_{days}D({child_entity_id}.{feature}{where_string})".format(
            func=func.upper(),
            days=str(self.kwargs["days"]),
            child_entity_id=child_entity_id,
            feature=base_feature_names[0],
            where_string=kwargs["where_str"],
        )
        for func in CURRENT_FUNCTIONS
    ]
    return names


MULTIPLE_AGG_LAST_X_DAYS = ft.primitives.make_agg_primitive(
    function=multiple_agg_last_x_days,  # function to be used
    input_types=[
        ft.variable_types.Numeric,
        ft.variable_types.DatetimeTimeIndex,
    ],  # input data types
    number_output_features=len(CURRENT_FUNCTIONS),
    return_type=ft.variable_types.Numeric,  # data types to be returned
    uses_calc_time=True,  # whether function can utilize cutoff time information
    stack_on_self=False,  # whether the primitive could be stacked on itself
    # AT THE MOMENT IT IS IMPOSSIBLE TO NAME MULTIPLE FEATURES AT ONCE
    # CHECK STATUS OF THE PROBLEM AT
    # https://github.com/Featuretools/featuretools/issues/593
    #     cls_attributes={
    #         "generate_name": multiple_agg_last_x_days_generate_name
    #     },  # passing of name generating function
)

