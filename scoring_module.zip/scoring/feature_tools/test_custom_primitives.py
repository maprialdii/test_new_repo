import featuretools as ft
import pandas as pd

from custom_primitives import AGG_LAST_X_DAYS

df = pd.DataFrame(
    {
        "ID": [1, 1, 1, 1, 2, 2],
        "dtime": [
            "2016-06-28 09:51:51.0",
            "2017-06-03 12:16:08.0",
            "2017-07-02 12:15:08.0",
            "2017-07-04 12:15:08.0",
            "2017-07-02 12:15:08.0",
            "2017-07-05 13:15:08.0",
        ],
        "value": [0, 3.0, 5, 0, 11, 14],  # float
        "value2": [1, 11, 1, 1, 11, 11],  # int
    }
)

VALUE_COLUMNS = ["value", "value2"]

cutoff_times = pd.DataFrame(
    {"ID": [1, 2], "time": ["2017-07-03 12:15:08.0", "2017-07-03 12:15:08.0"]}
)
df["dtime"] = pd.to_datetime(df["dtime"])
cutoff_times["time"] = pd.to_datetime(cutoff_times["time"])

es = ft.EntitySet("Dataset")
es.entity_from_dataframe(
    dataframe=df, entity_id="CAPP", index="index", time_index="dtime"
)

es.normalize_entity(
    base_entity_id="CAPP", new_entity_id="CLIENT", index="ID", make_time_index=False
)


def test_agg_last_1000_days():
    fm, features = ft.dfs(
        entityset=es,
        target_entity="CLIENT",
        agg_primitives=[AGG_LAST_X_DAYS(func="mean", days=1000)],
    )
    assert fm is not None
    assert features is not None
    assert fm.shape[0] == len(df.ID.unique())
    assert fm.shape[1] == len(VALUE_COLUMNS)


def test_agg_last_1000_days_with_cutoff():
    fm, features = ft.dfs(
        entityset=es,
        target_entity="CLIENT",
        agg_primitives=[AGG_LAST_X_DAYS(func="mean", days=1000)],
        cutoff_time=cutoff_times,
    )
    assert fm is not None
    assert features is not None
    assert fm.shape[0] == len(df.ID.unique())
    assert fm.shape[1] == len(VALUE_COLUMNS)
    # trans_primitives=['divide_numeric'],#,ft.primitives.DivideNumeric()
    # cutoff_time=cutoff_times,
    # max_depth=2,
    # training_window = ft.Timedelta(100,"d"),
    # verbose=True,
    # n_jobs=1,
