"""
Home Credit Python Scoring Library and Workflow
Copyright © 2017-2019, Pavel Sůva, Marek Teller, Martin Kotek, Jan Zeller, 
Marek Mukenšnabl, Kirill Odintsov, Elena Kuchina, Jan Coufalík, Jan Hynek and
Home Credit & Finance Bank Limited Liability Company, Moscow, Russia.
All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""

import re


def xgb_to_sql(filename_xgb, filename_sql, table_name, cat_numeric_columns=[], cat_str_columns=[]):
    """
    Plain XGBoost model dump file converter to SQL script.
    
    :param filename_xgb: name of file with xgb model in native format (saved with booster.dump_model(...))
    :param filename_sql: name of file to store sql script
    :param table_name: name of table with predictors
    :param cat_numeric_columns: list of numerical categorical columns
    :param cat_str_columns: list of categorical columns
    """
    cnt = 0

    def f():
        nonlocal cnt
        while True:
            line = next(lines)
            line = line[:-1]
            res = re.findall('^booster\[\d+\]:$', line)
            if not res:
                break
            else:
                if len(s)>1:
                    cnt += 1
                    s.append('+')
                    s.append('---------------------{}'.format(cnt))
        res=re.findall('(\t*)(\d+):leaf=(.*)$', line)
        if res:
            tabs, numb, score=res[0]
            s.append('{}{}'.format(tabs,score))
            return

        res = re.findall('(\t*)\d+:\[([_a-zA-Zа-яА-Я0-9/\.+ -]+)([><=]+)(.+)\] yes=(\d+),no=(\d+)', line)
        # print('x{}y'.format(res))
        if res:
            tabs, var, sign, const, yes, no=res[0]
            res = re.findall(',missing=(\d+)', line)
            missing = None
            if res:
                missing = res[0]

            flag = False
            for c in cat_columns:
                if var.startswith(c):
                    const = var[len(c)+1:]
                    var = c
                    if const == 'nan':
                        const = None
                    elif c in cat_str_columns:
                        const = '\'' + const + '\''
                    flag = True
                    break
            # var=mp(var)
            if flag:
                if const is None:
                    s.append('{0:}case when {1:} is not null then'.format(tabs, var))
                else:
                    s.append('{0:}case when {1:} is null or {1:} {2:} {3:} then'.format(tabs, var, '<>', const))
                '''
                elif not missing:
                    s.append('{0:}if({1:} {2:} {3:}) then {{'.format(tabs, var, '<>', const))
                elif missing==yes:
                    s.append('{0:}if({1:} is unknown or {1:} {2:} {3:}) then {{'.format(tabs, var, '<>', const))
                elif missing==no:
                    s.append('{0:}if({1:} is known and {1:} {2:} {3:}) then {{'.format(tabs, var, '<>', const))
                '''
            else:
                if not missing:
                    s.append('{0:}case when {1:} {2:} {3:} then'.format(tabs, var, sign, const))
                elif missing == yes:
                    s.append('{0:}case when {1:} is null or {1:} {2:} {3:} then'.format(tabs, var, sign, const))
                elif missing == no:
                    s.append('{0:}case when {1:} {2:} {3:} then'.format(tabs, var, sign, const))

            f()
            # s.append(''.join(tabs)+'end');
            s.append(''.join(tabs)+'else')
            f()
            s.append(''.join(tabs)+'end')
            return
        raise ValueError
    
    lines = open(filename_xgb)
    cat_columns = cat_numeric_columns + cat_str_columns
    s = ['alter table &table_with_predictors add score_final number;']
    s.append('update &table_with_predictors')
    s.append('set score_final = ')
    s.append('1 - ( 1 / ( 1 + exp ( -  ( ')
    try:
        while True:
            f()           
    except StopIteration:        
        pass
    #s.append('from {}'.format(table_name))
    s.append('))));')
    with open(filename_sql, 'w') as f_out:
        f_out.write('\n'.join(s))
    #uncomment to debug
    #print('\n'.join(s))
