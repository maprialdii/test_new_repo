import pandas as pd
import numpy as np
import math as math
import abc
import seaborn as sns
from os import path

from .auxiliary import RussianImputer


class ProjectParameters(object):
    sample_dict = {}
    rowid_variable = "SKP_CREDIT_CASE"
    targets = []
    time_variable = "DATE_DECISION"
    segments = []
    predictors_woe = []
    predictors_grp = []
    scores = []
    masks = {}
    weight = None

    def _processSample(self, samples):
        """Returns a tuple (sample[pd.sr], name[str]) of mask and name for given sample or multiple samples..        
        Args:
            samples ([str, list(str)]): Names of samples, need to exist in ProjectParameters.masks dictionary.
        
        Returns:
            tuple (sample[pd.sr], name[str]): mask sample or multiple samples
        """
        from functools import reduce

        if isinstance(samples, str):
            if samples in self.sample_dict.keys():
                return tuple([self.sample_dict[samples],samples])
            elif samples.upper() in ['ALL']:
                #get copy of a random mask and set all to True
                all_mask = next(iter(self.sample_dict.values())).copy()
                all_mask.loc[:] = True
                return tuple([all_mask, "All"])
            else:
                raise ValueError(f"Sample `{samples}` not in documentations samples.")
        elif isinstance(samples, list):
            for sample in samples:
                if isinstance(sample, str):
                    if sample not in self.sample_dict.keys():
                        raise ValueError(f"Sample `{sample}` not in documentations samples.")
                else:
                    raise ValueError(f"Sample `{sample}` is not valid sample name.")
            masks = [self.sample_dict[name] for name in samples]
            merged_masks = reduce(lambda a,b: a | b, masks)
            merged_names = '+'.join(samples)
            return tuple([merged_masks, merged_names])
        else:
            raise ValueError(f"Sample `{samples}` not a valid sample.")

    # def _processSample(self, samples):
    #     """Returns a tuple (sample[pd.df], name) for specified sample
    #     or union of samples
        
    #     Args:
    #         samples ([str, list(str)]): Sample names or list of names. Must exist in documentation
        
    #     Returns:
    #         ([pd.df],[str]): A tuple of sample and name of sample
    #     """
    #     if isinstance(samples, str):
    #         if samples in self.sample_dict.keys():
    #             return tuple([self.sample_dict[samples], samples])
    #         elif samples.upper() in ['ALL']:
    #             merged_samples = pd.concat([sample for name, sample in self.sample_dict.items()])
    #             return tuple([merged_samples, "All"])
    #         else:
    #             raise ValueError(f"Sample `{samples}` not in documentations samples.")
    #     elif isinstance(samples, list):
    #         for sample in samples:
    #             if isinstance(sample, str):
    #                 if sample not in self.sample_dict.keys():
    #                     raise ValueError(f"Sample `{sample}` not in documentations samples.")
    #             else:
    #                 raise ValueError(f"Sample `{sample}` is not valid sample name.")
    #         merged_samples = pd.concat([self.sample_dict[sample] for sample in samples])
    #         merged_names = '+'.join(samples)
    #         return tuple([merged_samples, merged_names])
    #     else:
    #         raise ValueError(f"Sample `{samples}` not a valid sample.")

    def _processTarget(self, targets):
        """"Returns a tuple (targer, base) of column names."
        
        Args:
            targets ([type]): [description]
        
        Returns:
            [type]: [description]
        """
        target_tuple = [(tar, base) for tar, base in self.targets if tar == targets][0]
        return target_tuple


    def ContinuousEvaluation(self, data, predictor, sample, target, output_folder=None):
        cec = ContinuousEvaluationCalculator(self)
        # plt.rcParams["lines.marker"] = "D"

        sample_mask, sample_name = self._processSample(sample)
        sample_tuple = (data[sample_mask], sample_name)
        
        if self.rowid_variable not in sample_tuple[0].columns:
            pd.set_option('mode.chained_assignment', None)
            sample_tuple[0][self.rowid_variable] = sample_tuple[0].index
            pd.set_option('mode.chained_assignment', 'warn')

        
        target_tuple = self._processTarget(target)
        cec.s([sample_tuple]).p([predictor]).t([target_tuple])
        cec.calculate().get_visualization(output_folder=output_folder)

    def GroupedEvaluation(self, data, predictor, sample, target, grouping=None, weight=None, output_folder=None):
        gec = GroupingEvaluationCalculator(self)
        # plt.rcParams["lines.marker"] = "D"

        sample_mask, sample_name = self._processSample(sample)
        sample_tuple = (data[sample_mask], sample_name)
        if self.rowid_variable not in sample_tuple[0].columns:
            pd.set_option('mode.chained_assignment', None)
            sample_tuple[0][self.rowid_variable] = sample_tuple[0].index
            pd.set_option('mode.chained_assignment', 'warn')
        
        target_tuple = self._processTarget(target)
        gec.s([sample_tuple]).p([predictor]).t([target_tuple]).g(grouping).w(weight)
        gec.calculate().get_visualization(output_folder=output_folder)

    def Correlations(self, data, predictors, sample, output_folder=None, filename=None):
        sample_mask, sample_name = self._processSample(sample)
        sample_tuple = (data[sample_mask], sample_name)
        
        cormat_full = sample_tuple[0][sorted(predictors)].fillna(0).corr()

        a4_dims = (12,10)

        fig, ax = plt.subplots(figsize=a4_dims, dpi=50)
        fig.suptitle('Correlations of Variables',fontsize=25)
        sns.heatmap(cormat_full, ax=ax, annot=True, fmt="0.1f", linewidths=.5, annot_kws={"size":15},cmap="OrRd")
        plt.tick_params(labelsize=15)
        plt.xticks(rotation=90)
        plt.yticks(rotation=0)
        if output_folder:
            plt.savefig(output_folder + filename, bbox_inches='tight', dpi = 72)
        plt.show()
        plt.clf();plt.close()

    def ScoreCalibration(self, data, score, sample, target, bins=50, output_folder=None, swap_probability=False, filename="calibration.png"):
        sample_mask, sample_name = self._processSample(sample)
        sample_tuple = (data[sample_mask], sample_name)
        
        
        score = sample_tuple[0][score]
        target = sample_tuple[0][target]
        bins = np.percentile(score, np.linspace(0,100, bins + 1))

        scores = []
        brs = []
        for b in zip(bins[:-1], bins[1:]):
            if swap_probability:
                scores += [1 - score[(score>=b[0]) & (score<b[1])].mean()]
            else:
                scores += [score[(score>=b[0]) & (score<b[1])].mean()]
            brs += [target[(score>=b[0]) & (score<b[1])].mean()]

        plt.scatter(scores, brs)
        upperlimit = np.nanmax(scores + brs)
        plt.xlim([0, upperlimit])
        plt.ylim([0, upperlimit])
        plt.plot(np.linspace(0, upperlimit, 1000), np.linspace(0, upperlimit, 1000) , color='red', marker="None")    
        plt.grid()
        plt.ylabel('default rate')
        plt.xlabel('prediction')
        if output_folder is not None:
            plt.savefig(output_folder + filename, bbox_inches='tight', dpi = 72)
        plt.show()

    def ScoreComparison(self, data, scores, sample, target, output_folder=None, filename=None):
        scc = ScoreComparisonCalculator(self)
        # plt.rcParams["lines.marker"] = "D"

        sample_mask, sample_name = self._processSample(sample)
        sample_tuple = (data[sample_mask], sample_name)
        if self.rowid_variable not in sample_tuple[0].columns:
            pd.set_option('mode.chained_assignment', None)
            sample_tuple[0][self.rowid_variable] = sample_tuple[0].index
            pd.set_option('mode.chained_assignment', 'warn')
        
        target_tuple = self._processTarget(target)
        scc.s([sample_tuple]).p(scores).t([target_tuple])
        scc.calculate().get_visualization(output_folder=output_folder, filename=filename)


    def GroupingPlots(self, data, predictors, sample, target, grouping, weight=None, output_folder=None):
        sample_mask, sample_name = self._processSample(sample)
        sample_tuple = (data[sample_mask], sample_name)
        if self.rowid_variable not in sample_tuple[0].columns:
            pd.set_option('mode.chained_assignment', None)
            sample_tuple[0][self.rowid_variable] = sample_tuple[0].index
            pd.set_option('mode.chained_assignment', 'warn')
        
        target_tuple = self._processTarget(target)

        for col in predictors:
            if col not in grouping.bins_data_.keys():
                raise ValueError(f"{col} is missing in grouping.")

        predictors_categorical = [pred for pred in predictors if pred in grouping.cat_columns]
        predictors_numerical = [pred for pred in predictors if pred in grouping.columns]

        #create a mask that contains whole sample
        fake_mask = [True] * sample_tuple[0].shape[0]

        grouping.plot_bins(data=sample_tuple[0],
                           cols_pred_num=predictors_numerical,
                           cols_pred_cat=predictors_categorical,
                           mask=fake_mask,
                           col_target=target_tuple[0],
                           output_folder=output_folder,
                           col_weight=weight
        )


class Calculator(object, metaclass=abc.ABCMeta):

    samples = []
    targets = []
    predictors = []
    scores = []
    predictors_to_add = []

    description = None
    rowid_variable = None
    time_variable = None
    weight = None

    projectParameters = None

    def __init__(self, projectParameters=ProjectParameters()):
        self.projectParameters = projectParameters
        self.rowid_variable = projectParameters.rowid_variable
        self.time_variable = projectParameters.time_variable
        self.targets = projectParameters.targets
        self.masks = projectParameters.masks
        self.scores = (
            projectParameters.scores
        )
         # [(projectParameters.sample_dict[sample_name], sample_name) for sample_name in projectParameters.sample_ordering]

    # sets array of sample s
    def s(self, samples):

        ## add input checking

        self.samples = samples
        return self

    # sets array of targets
    def t(self, targets):
        self.targets = targets
        return self

    # sets array of predictors
    def p(self, predictors):
        self.predictors = predictors
        return self

    # sets array of scores
    def sc(self, scores):
        self.scores = scores
        return self

    # sets array of segmentations
    def sg(self, segments):
        self.segments = segments
        return self

    # sets array of predictors to add for marginal contribution
    def padd(self, predictors_to_add):
        self.predictors_to_add = predictors_to_add
        return self

    # overrides the project-lvl time variable
    def tm(self, time_variable):
        self.time_variable = time_variable
        return self

    # set weight
    def w(self, weight_col):
        self.weight = weight_col
        return self

    # set grouping
    def g(self, grouping):
        self.grouping = grouping
        return self

    # returns hash of the description
    def get_hash(self):
        import hashlib

        hash_object = hashlib.md5(self.get_description())
        return hash_object.hexdigest()

    def replace_legend(self, woe, predictor, grouping=None):
        """
        Tries to replace a woe value with interval or list of values if grouping was provided.
        If no grouping was provided returns original value.

        Args:
            woe (float): woe value to be replaced
        """
        grouping_dictionary = grouping.export_dictionary()
        woe = np.float32(woe)


        if grouping:
            new_value = grouping_dictionary[predictor][round(woe,5)]

            # if value is list of strings lets join them
            if type(new_value) is list:
                group_name = [str(i) for i in new_value]
                # split into chunks of five
                group_name = [",".join(group_name[i:i+5]) for i in range(0,len(group_name),5)]
                # each chuck get a new line
                group_name = "\n".join([str(i) for i in group_name])

                return group_name
            else:
                return new_value 
        else:
            return woe


    # these need to be implemented by further developers
    @abc.abstractmethod
    def calculate(self):
        return

    @abc.abstractmethod
    def get_table(self):
        return

    @abc.abstractmethod
    def get_visualization(self):
        return

    @abc.abstractmethod
    def get_description(self):
        return


# expects one sample
# accepts multiple targets


class SampleDescriptionCalculator(Calculator):
    def calculate(self):
        pivots = []

        # declaration of all used external variables
        # ------------------------------------------
        df = self.samples[0][0]
        targets = self.targets
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        a = pd.pivot_table(df, index=time_variable, values=rowid_col, aggfunc=[len], dropna=False, fill_value=0)
        a.columns = pd.Index(["Observations"])
        pivots.append(a)

        for target in targets:
            p = pd.pivot_table(
                df[df[target[1]] == 1],
                index=time_variable,
                values=target[0],
                columns=target[1],
                aggfunc=[len, np.sum, np.mean],
                dropna=False,
                fill_value=0,
            )
            p.columns = pd.Index([target[0] + " measurable", target[0] + " bads", target[0] + " default rate"])
            pivots.append(p)

        r = pd.concat(pivots, axis=1, sort=False)
        r2 = pd.DataFrame(r.apply(np.sum)).T

        for target in targets:
            r2[target[0] + " default rate"] = r2[target[0] + " bads"] / r2[target[0] + " measurable"]

        r2 = r2.set_index(pd.Index(["All"]))
        self.table = pd.concat([r, r2], sort=False)
        self.table.columns = pd.MultiIndex.from_product([["Sample description"], self.table.columns])

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        return self

    def get_description(self):
        return "Description of sample " + self.samples[0][1]


# Matus adjusted sample description by segments
class SampleDescriptionSegmentsCalculator(Calculator):
    def calculate(self):
        pivots = []

        # declaration of all used external variables
        # ------------------------------------------
        df = self.samples[0][0]
        targets = self.targets
        predictors = self.predictors
        rowid_col = self.rowid_variable
        segment = self.segments[0]
        # ---------------------------------

        a = pd.pivot_table(df, index=segment, values=rowid_col, aggfunc=[len], dropna=False, fill_value=0)
        a["rel"] = a.len / a.len.sum()
        a.columns = pd.Index(["Observations", "Share"])
        pivots.append(a)

        for target in targets:
            p = pd.pivot_table(
                df[df[target[1]] == 1],
                index=segment,
                values=target[0],
                columns=target[1],
                aggfunc=[len, np.sum, np.mean],
                dropna=False,
                fill_value=0,
            )
            p.columns = pd.Index([target[0] + " measurable", target[0] + " bads", target[0] + " default rate"])
            pivots.append(p)
            for predictor in predictors:
                p = pd.pivot_table(
                    df[df[target[1]] == 1],
                    index=segment,
                    values=predictor,
                    columns=target[1],
                    aggfunc=[np.mean],
                    dropna=False,
                    fill_value=0,
                )
                p.columns = pd.Index(["AVG(" + predictor + ") on " + target[0] + " meas."])
                pivots.append(p)

        r = pd.concat(pivots, axis=1, sort=False)
        r2 = pd.DataFrame(r.apply(np.sum)).T

        for target in targets:
            r2[target[0] + " default rate"] = r2[target[0] + " bads"] / r2[target[0] + " measurable"]
            for predictor in predictors:
                r2["AVG(" + predictor + ") on " + target[0] + " meas."] = (
                    r["AVG(" + predictor + ") on " + target[0] + " meas."].multiply(r[target[0] + " measurable"]).sum()
                    / r2[target[0] + " measurable"]
                )

        r2 = r2.set_index(pd.Index(["All"]))
        self.table = pd.concat([r, r2], sort=False)
        self.table.columns = pd.MultiIndex.from_product([["Sample description"], self.table.columns])

        return self

    def get_table(self):
        return self.table

    def get_visualization(self, ax=None):
        return self

    def get_description(self):
        return "Description of sample " + self.samples[0][1] + " by segments of " + self.segments[0]


# import Calculator

# expect only one sample
# expects only one target variable
# expects only one predictor


class PredictorRiskInTimeCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------
        self.table = pd.pivot_table(
            df[df[target[1]] == 1],
            index=time_variable,
            values=target[0],
            columns=predictor,
            aggfunc=[len, np.sum, np.mean],
            margins=True,
        )

        pred_cat = list(set(self.table.columns.values))
        pred_cat = self.table.columns.levels[1].values
        stat = ["Meas. obs.", "Bads", "Bad rate"]
        self.table.columns = pd.MultiIndex.from_product([stat, pred_cat])
        return self

    def calculate_weighted(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0].copy()
        target = self.targets[0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        weight_col = self.weight

        target_weighted = f"{target}_{weight_col}"

        df[target_weighted] = df[target[0]] * df[weight_col]
        # ---------------------------------
        self.table = pd.pivot_table(
            df[df[target[1]] == 1],
            index=time_variable,
            values=[target_weighted, weight_col],
            columns=predictor,
            aggfunc=np.sum,
            margins=True,
        )

        self.table = self.table[[weight_col, target_weighted]]

        table_weighted_mean = self.table[target_weighted] / self.table[weight_col]
        table_weighted_mean.columns = pd.MultiIndex.from_product([["w_mean"], table_weighted_mean.columns.values])
        self.table = pd.concat([self.table, table_weighted_mean], axis=1)
        pred_cat = list(set(self.table.columns.values))
        pred_cat = self.table.columns.levels[1].values
        stat = ["Meas. obs.", "Bads", "Bad rate"]
        self.table.columns = pd.MultiIndex.from_product([stat, pred_cat])
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        br = self.table["Bad rate"]
        yaxislim = math.ceil(1.2 * br.max().max() * 40) / 40
        del br["All"]
        br.drop("All")
        ax = br.plot(ylim=(0, yaxislim), title="Risk of " + self.predictors[0] + " on " + self.targets[0][0])
        ax.set_xticks(list(np.arange(br.shape[0])))
        ax.set_xticklabels(br.index)
        plt.show()

    def get_description(self):
        return (
            "Risk of predictor "
            + self.predictors[0]
            + " on target "
            + self.targets[0][0]
            + " on sample "
            + self.samples[0][1]
        )


# import Calculator

# expect only one sample
# expects only one predictor


class PredictorShareInTimeCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        cnt = pd.pivot_table(df, index=time_variable, columns=predictor, values=rowid_col, aggfunc=len, margins=True)
        share = cnt.apply(lambda x: x / x["All"], axis=1)

        self.table = pd.concat([cnt, share], axis=1, sort=False)

        pred_cat = list(share.columns.values)
        stat = ["All obs.", "Share"]
        self.table.columns = pd.MultiIndex.from_product([stat, pred_cat])
        return self

    def calculate_weighted(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        weight_col = self.weight
        # ---------------------------------

        cnt = pd.pivot_table(df, index=time_variable, columns=predictor, values=weight_col, aggfunc=sum, margins=True)
        share = cnt.apply(lambda x: x / x["All"], axis=1)

        self.table = pd.concat([cnt, share], axis=1, sort=False)

        pred_cat = list(share.columns.values)
        stat = ["All obs.", "Share"]
        self.table.columns = pd.MultiIndex.from_product([stat, pred_cat])
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        piv = self.table["Share"]
        del piv["All"]
        piv.drop("All")
        ax = piv.plot(ylim=(0, 1), title="Share of " + self.predictors[0])
        ax.set_xticks(list(np.arange(piv.shape[0])))
        ax.set_xticklabels(piv.index)

        plt.show()
        return

    def get_description(self):
        return "Share of predictor " + self.predictors[0] + " on sample " + self.samples[0][1]


# import Calculator

# expect only one sample
# expects only one target variable
# expects one or more predictors


class PredictorGiniInTimeCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        targets = self.targets
        predictors = self.predictors
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        def gini(x):
            from sklearn import metrics
            import pandas as pd
            import numpy as np

            def unzip_scoretarget_tuple(x):
                prep = list(zip(*x.values))
                target_ = prep[0]
                prediction_ = prep[1]
                return [target_, prediction_]

            target_, prediction_ = unzip_scoretarget_tuple(x)
            if np.min(target_) < np.max(target_):  # we need 2 classes to calculate gini
                return 100 * (metrics.roc_auc_score(target_, prediction_) * 2 - 1)
            else:
                return np.nan  # gini not defined

        df = df.copy()

        # if the predictor is categorical one, encode it with badrate first
        # for predictor in predictors:

        # prepare combinations of predictor and target

        arr_t = []
        for target in targets:
            arr_p = []
            for predictor in predictors:

                if df[predictor].dtype == "O":
                    df_piv = pd.pivot_table(
                        df, index=predictor, columns=target[0], values=rowid_col, aggfunc=len, fill_value=0
                    )
                    df_piv["br"] = df_piv.apply(lambda x: 1.00 * x[1] / (x[0] + x[1]), axis=1)
                    df_piv = pd.DataFrame(df_piv.reset_index().values, columns=[predictor, "goods", "bads", "br"])
                    df = (
                        df[[rowid_col, time_variable, target[0], target[1]] + predictors]
                        .copy()
                        .reset_index()
                        .merge(df_piv, on=predictor, how="left")
                        .set_index("index")
                    )
                    df[predictor] = df["br"]

                # ri = RussianImputer().fit(df[df[target[1]] == 1][predictor], df[df[target[1]] == 1][target[0]])
                # df[predictor] = ri.transform(df[df[target[1]] == 1][predictor])

                target_predictor_col = target[0] + predictor + "_tuple"
                df[target_predictor_col] = df[[target[0], predictor]].apply(
                    lambda x: (x[target[0]], x[predictor]), axis=1
                )
                # display(df[(df[target[1]] == 1) & (~df[predictor].isnull())])
                gini_results = pd.pivot_table(
                    df[(df[target[1]] == 1) & ~df[predictor].isnull()], index=time_variable, values=target_predictor_col, aggfunc=gini, margins=True
                )

                overall_gini_sign = gini_results.loc["All"][0]
                gini_results = gini_results.apply(lambda x: x * 1 if overall_gini_sign >= 0 else -1 * x)
                arr_p.append(gini_results)

            t = pd.concat(arr_p, axis=1, sort=False)
            t.columns = pd.MultiIndex.from_product([["Gini " + target[0]], predictors])
            arr_t.append(t)

            for predictor in predictors:
                del df[target[0] + predictor + "_tuple"]

        # return final reults
        self.table = pd.concat(arr_t, axis=1, sort=False)

        return self

    def calculate_weighted(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        targets = self.targets
        predictors = self.predictors
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        weight_col = self.weight
        # ---------------------------------

        def gini(x):
            from sklearn import metrics
            import pandas as pd
            import numpy as np

            def unzip_scoretargetweight_tuple(x):
                target, prediction, weight = list(zip(*x.values))
                return target, prediction, weight

            target_, prediction_, weight_ = unzip_scoretargetweight_tuple(x)
            if np.min(target_) < np.max(target_):  # we need 2 classes to calculate gini
                return 100 * (metrics.roc_auc_score(target_, prediction_, sample_weight=weight_) * 2 - 1)
            else:
                return np.nan  # gini not defined

        df = df.copy()

        # if the predictor is categorical one, encode it with badrate first
        # for predictor in predictors:

        # prepare combinations of predictor and target

        arr_t = []
        for target in targets:
            arr_p = []
            for predictor in predictors:

                if df[predictor].dtype == "O":
                    df_piv = pd.pivot_table(
                        df, index=predictor, columns=target[0], values=rowid_col, aggfunc=len, fill_value=0
                    )
                    df_piv["br"] = df_piv.apply(lambda x: 1.00 * x[1] / (x[0] + x[1]), axis=1)
                    df_piv = pd.DataFrame(df_piv.reset_index().values, columns=[predictor, "goods", "bads", "br"])
                    df = (
                        df[[rowid_col, time_variable, target[0], target[1]] + predictors]
                        .copy()
                        .reset_index()
                        .merge(df_piv, on=predictor, how="left")
                        .set_index("index")
                    )
                    df[predictor] = df["br"]

                # ri = RussianImputer().fit(df[df[target[1]] == 1][predictor], df[df[target[1]] == 1][target[0]])
                # df[predictor] = ri.transform(df[df[target[1]] == 1][predictor])

                target_predictor_col = target[0] + predictor + weight_col +"_tuple"
                df[target_predictor_col] = df[[target[0], predictor, weight_col]].apply(
                    lambda x: (x[target[0]], x[predictor], x[weight_col]), axis=1
                )
                # display(df[(df[target[1]] == 1) & (~df[predictor].isnull())])
                gini_results = pd.pivot_table(
                    df[(df[target[1]] == 1) & ~df[predictor].isnull()], index=time_variable, values=target_predictor_col, aggfunc=gini, margins=True
                )

                overall_gini_sign = gini_results.loc["All"][0]
                gini_results = gini_results.apply(lambda x: x * 1 if overall_gini_sign >= 0 else -1 * x)
                arr_p.append(gini_results)

            t = pd.concat(arr_p, axis=1, sort=False)
            t.columns = pd.MultiIndex.from_product([["Gini " + target[0]], predictors])
            arr_t.append(t)

            for predictor in predictors:
                del df[target[0] + predictor + weight_col +"_tuple"]

        # return final reults
        self.table = pd.concat(arr_t, axis=1, sort=False)

        return self   

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        gini_results = self.table
        # print(gini_results)
        gini_results = gini_results.drop("All")
        ax = gini_results.plot(title="Gini of " + self.predictors[0] + " on " + self.targets[0][0], ylim=(0, 100))
        ax.set_xticks(list(np.arange(gini_results.shape[0])))
        ax.set_xticklabels(gini_results.index)
        plt.show()
        return self

    def get_description(self):
        if len(self.predictors) == 1 and len(self.targets) == 1:
            return (
                "Gini of predictor "
                + self.predictors[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
            )
        elif len(self.predictors) > 1 and len(self.targets) > 1:
            return "Gini of multiple predictors " + " on multiple targets " + "on sample " + self.samples[0][1]
        elif len(self.predictors) > 1:
            return "Gini of multiple predictors on target " + self.targets[0][0] + " on sample " + self.samples[0][1]
        elif len(self.targets) > 1:
            return (
                "Gini of predictor " + self.predictors[0] + " on multiple targets " + " on sample " + self.samples[0][1]
            )


# Matus adjusted - adding Gini by segments calculator
class PredictorGiniBySegmentsCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        targets = self.targets
        predictors = self.predictors
        rowid_col = self.rowid_variable
        segment = self.segments[0]
        # ---------------------------------

        def gini(x):
            from sklearn import metrics
            import pandas as pd
            import numpy as np

            def unzip_scoretarget_tuple(x):
                prep = list(zip(*x.values))
                target_ = prep[0]
                prediction_ = prep[1]
                return [target_, prediction_]

            target_, prediction_ = unzip_scoretarget_tuple(x)
            if np.min(target_) < np.max(target_):  # we need 2 classes to calculate gini
                return 100 * (metrics.roc_auc_score(target_, prediction_) * 2 - 1)
            else:
                return np.nan  # gini not defined

        df = df.copy()

        # if the predictor is categorical one, encode it with badrate first
        # for predictor in predictors:

        # prepare combinations of predictor and target

        arr_t = []
        for target in targets:
            arr_p = []
            for predictor in predictors:

                if df[predictor].dtype == "O":
                    df_piv = pd.pivot_table(
                        df, index=predictor, columns=target[0], values=rowid_col, aggfunc=len, fill_value=0
                    )
                    df_piv["br"] = df_piv.apply(lambda x: 1.00 * x[1] / (x[0] + x[1]), axis=1)
                    df_piv = pd.DataFrame(df_piv.reset_index().values, columns=[predictor, "goods", "bads", "br"])
                    df = (
                        df[[rowid_col, segment, target[0], target[1]] + predictors]
                        .copy()
                        .reset_index()
                        .merge(df_piv, on=predictor, how="left")
                        .set_index("index")
                    )
                    df[predictor] = df["br"]

                # ri = RussianImputer().fit(df[df[target[1]] == 1][predictor], df[df[target[1]] == 1][target[0]])
                # df[predictor] = ri.transform(df[df[target[1]] == 1][predictor])

                target_predictor_col = target[0] + predictor + "_tuple"
                df[target_predictor_col] = df[[target[0], predictor]].apply(
                    lambda x: (x[target[0]], x[predictor]), axis=1
                )
                gini_results = pd.pivot_table(
                    df[df[target[1]] == 1], index=segment, values=target_predictor_col, aggfunc=gini, margins=True
                )

                overall_gini_sign = gini_results.loc["All"][0]
                gini_results = gini_results.apply(lambda x: x * 1 if overall_gini_sign >= 0 else -1 * x)
                arr_p.append(gini_results)

            t = pd.concat(arr_p, axis=1, sort=False)
            t.columns = pd.MultiIndex.from_product([["Gini " + target[0]], predictors])
            arr_t.append(t)

            for predictor in predictors:
                del df[target[0] + predictor + "_tuple"]

        # return final results
        self.table = pd.concat(arr_t, axis=1, sort=False)

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        gini_results = self.table
        # print(gini_results)
        gini_results = gini_results.drop("All")
        ax = gini_results.plot(
            title="Gini of "
            + self.predictors[0]
            + " on "
            + self.targets[0][0]
            + "\n by segments of "
            + self.segments[0],
            ylim=(0, 100),
        )
        ax.set_xticks(list(np.arange(gini_results.shape[0])))
        ax.set_xticklabels(gini_results.index)
        plt.show()
        return self

    def get_description(self):
        if len(self.predictors) == 1 and len(self.targets) == 1:
            return (
                "Gini of predictor "
                + self.predictors[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
                + " by segments of "
                + self.segments[0]
            )
        elif len(self.predictors) > 1 and len(self.targets) > 1:
            return (
                "Gini of multiple predictors "
                + " on multiple targets "
                + "on sample "
                + self.samples[0][1]
                + " by segments of "
                + self.segments[0]
            )
        elif len(self.predictors) > 1:
            return (
                "Gini of multiple predictors on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
                + " by segments of "
                + self.segments[0]
            )
        elif len(self.targets) > 1:
            return (
                "Gini of predictor "
                + self.predictors[0]
                + " on multiple targets "
                + " on sample "
                + self.samples[0][1]
                + " by segments of "
                + self.segments[0]
            )


# import Calculator

# expect only one sample
# expects only one target variable
# expects one or more predictors (only continuous)


class PredictorLiftInTimeCalculator(Calculator):
    def liftN(self, x, q):
        def unzip_scoretarget_tuple(x):
            prep = list(zip(*x.values))
            target_ = prep[0]
            prediction_ = prep[1]
            return [target_, prediction_]

        target_, prediction_ = unzip_scoretarget_tuple(x)
        df = pd.DataFrame([pd.Series(target_, name="target"), pd.Series(prediction_, name="prediction")]).T
        # print(df)
        quant_ = df["prediction"].quantile(q)
        pop_dr = df["target"].mean()
        q_dr = df["target"][df["prediction"] > quant_].mean()
        if pop_dr == 0:
            return np.nan
        else:
            lift = 1.0 * q_dr / pop_dr
        return lift

    def lift05(self, x):
        return self.liftN(x, 0.95)

    def lift10(self, x):
        return self.liftN(x, 0.9)

    def lift20(self, x):
        return self.liftN(x, 0.8)

    def lift30(self, x):
        return self.liftN(x, 0.7)

    def lift40(self, x):
        return self.liftN(x, 0.6)

    def lift50(self, x):
        return self.liftN(x, 0.5)

    def lift60(self, x):
        return self.liftN(x, 0.4)

    def lift70(self, x):
        return self.liftN(x, 0.3)

    def lift80(self, x):
        return self.liftN(x, 0.2)

    def lift90(self, x):
        return self.liftN(x, 0.1)

    def get_all_lifts(self):
        return [
            self.lift05,
            self.lift10,
            self.lift20,
            self.lift30,
            self.lift40,
            self.lift50,
            self.lift60,
            self.lift70,
            self.lift80,
            self.lift90,
        ]

    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictors = self.predictors
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        # if the predictor is categorical one, encode it with badrate first
        # for predictor in predictors:
        #    if df[predictor].dtype == 'O':
        #        df_piv = pd.pivot_table(df, index=predictor, columns=target[0], values=rowid_col, aggfunc=len, fill_value=0)
        #        df_piv['br'] = df_piv.apply(lambda x: 1.00 * x[1] / ( x[0] + x[1] ), axis=1)
        #        df_piv = pd.DataFrame(df_piv.reset_index().values, columns=[predictor,'goods','bads','br'])
        #        df = df[[rowid_col, time_variable, target[0], target[1]] + predictors].copy().reset_index().merge(df_piv, on=predictor, how='left').set_index('index')
        #        df[predictor] = df['br']

        # prepare combinations of predictor and target

        pd.options.mode.chained_assignment = None  # default='warn'

        arr = []
        for predictor in predictors:
            target_predictor_col = target[0] + predictor + "_tuple"
            df[target_predictor_col] = df[[target[0], predictor]].apply(lambda x: (x[target[0]], x[predictor]), axis=1)
            lift_results = pd.pivot_table(
                df[df[target[1]] == 1],
                index=time_variable,
                values=target_predictor_col,
                aggfunc=self.lift10,
                margins=True,
            )
            lift_results.columns = ["Lift"]
            lift_results.name = predictor
            arr.append(lift_results)

        # cleanup
        for predictor in predictors:
            del df[target[0] + predictor + "_tuple"]

        # return final reults
        self.table = pd.concat(arr, axis=1, sort=False)
        self.table = self.table
        self.table.columns = pd.MultiIndex.from_product([["Lift10"], self.predictors])

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        gini_results = self.table
        # print(gini_results)
        gini_results = gini_results.drop("All")
        ax = gini_results.plot(title="Lift10 of " + self.predictors[0] + " on " + self.targets[0][0], ylim=(0, 7))
        ax.set_xticks(list(np.arange(gini_results.shape[0])))
        ax.set_xticklabels(gini_results.index)

        plt.show()
        return self

    def get_description(self):
        if len(self.predictors) == 1:
            return (
                "Lift10 of predictor "
                + self.predictors[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
            )
        else:
            return (
                "Lift10 of multiple predictors "
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
            )


# Matus adjusted - adding Gini by segments calculator
class PredictorLiftBySegmentsCalculator(Calculator):
    def liftN(self, x, q):
        def unzip_scoretarget_tuple(x):
            prep = list(zip(*x.values))
            target_ = prep[0]
            prediction_ = prep[1]
            return [target_, prediction_]

        target_, prediction_ = unzip_scoretarget_tuple(x)
        df = pd.DataFrame([pd.Series(target_, name="target"), pd.Series(prediction_, name="prediction")]).T
        # print(df)
        quant_ = df["prediction"].quantile(q)
        pop_dr = df["target"].mean()
        q_dr = df["target"][df["prediction"] > quant_].mean()
        if pop_dr == 0:
            return np.nan
        else:
            lift = 1.0 * q_dr / pop_dr
        return lift

    def lift05(self, x):
        return self.liftN(x, 0.95)

    def lift10(self, x):
        return self.liftN(x, 0.9)

    def lift20(self, x):
        return self.liftN(x, 0.8)

    def lift30(self, x):
        return self.liftN(x, 0.7)

    def lift40(self, x):
        return self.liftN(x, 0.6)

    def lift50(self, x):
        return self.liftN(x, 0.5)

    def lift60(self, x):
        return self.liftN(x, 0.4)

    def lift70(self, x):
        return self.liftN(x, 0.3)

    def lift80(self, x):
        return self.liftN(x, 0.2)

    def lift90(self, x):
        return self.liftN(x, 0.1)

    def get_all_lifts(self):
        return [
            self.lift05,
            self.lift10,
            self.lift20,
            self.lift30,
            self.lift40,
            self.lift50,
            self.lift60,
            self.lift70,
            self.lift80,
            self.lift90,
        ]

    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictors = self.predictors
        rowid_col = self.rowid_variable
        segment = self.segments[0]
        # ---------------------------------

        # if the predictor is categorical one, encode it with badrate first
        # for predictor in predictors:
        #    if df[predictor].dtype == 'O':
        #        df_piv = pd.pivot_table(df, index=predictor, columns=target[0], values=rowid_col, aggfunc=len, fill_value=0)
        #        df_piv['br'] = df_piv.apply(lambda x: 1.00 * x[1] / ( x[0] + x[1] ), axis=1)
        #        df_piv = pd.DataFrame(df_piv.reset_index().values, columns=[predictor,'goods','bads','br'])
        #        df = df[[rowid_col, time_variable, target[0], target[1]] + predictors].copy().reset_index().merge(df_piv, on=predictor, how='left').set_index('index')
        #        df[predictor] = df['br']

        # prepare combinations of predictor and target
        arr = []
        for predictor in predictors:
            target_predictor_col = target[0] + predictor + "_tuple"
            df[target_predictor_col] = df[[target[0], predictor]].apply(lambda x: (x[target[0]], x[predictor]), axis=1)
            lift_results = pd.pivot_table(
                df[df[target[1]] == 1], index=segment, values=target_predictor_col, aggfunc=self.lift10, margins=True
            )
            lift_results.columns = ["Lift"]
            lift_results.name = predictor
            arr.append(lift_results)

        # cleanup
        for predictor in predictors:
            del df[target[0] + predictor + "_tuple"]

        # return final reults
        self.table = pd.concat(arr, axis=1, sort=False)
        self.table = self.table
        self.table.columns = pd.MultiIndex.from_product([["Lift10"], self.predictors])

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        gini_results = self.table
        # print(gini_results)
        gini_results = gini_results.drop("All")
        ax = gini_results.plot(
            title="Lift10 of "
            + self.predictors[0]
            + " on "
            + self.targets[0][0]
            + "\n by segments of "
            + self.segments[0],
            ylim=(0, 7),
        )
        ax.set_xticks(list(np.arange(gini_results.shape[0])))
        ax.set_xticklabels(gini_results.index)

        plt.show()
        return self

    def get_description(self):
        if len(self.predictors) == 1:
            return (
                "Lift10 of predictor "
                + self.predictors[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
                + " by segments of "
                + self.segments[0]
            )
        else:
            return (
                "Lift10 of multiple predictors "
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
                + " by segments of "
                + self.segments[0]
            )


class PredictorLiftCalculator(PredictorLiftInTimeCalculator):
    def calculate(self):

        df = self.samples[0][0]
        target = self.targets[0]
        predictors = self.predictors
        rowid_col = self.rowid_variable
        time_variable = self.time_variable

        arr = []
        for predictor in predictors:
            target_predictor_col = target[0] + predictor + "_tuple"
            df[target_predictor_col] = df[[target[0], predictor]].apply(lambda x: (x[target[0]], x[predictor]), axis=1)
            df["one"] = predictor
            lift_results = pd.pivot_table(
                df[df[target[1]] == 1],
                index="one",
                values=target_predictor_col,
                aggfunc=self.get_all_lifts(),
                margins=False,
            )
            lift_results.name = predictor
            a = lift_results.T.reset_index()[["level_0", predictor]]
            a.columns = ["Lift", predictor]
            a = a.set_index("Lift")
            arr.append(a)

        # cleanup
        for predictor in predictors:
            del df[target[0] + predictor + "_tuple"]
            # del df['one']

        # return final reults
        self.table = pd.concat(arr, axis=1, sort=False)
        self.table = self.table
        # self.table.column

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        ax = self.table.plot(title="Lift")
        ax.set_xticks(list(np.arange(self.table.shape[0])))
        ax.set_xticklabels(self.table.index)

        plt.show()

    def get_description(self):
        if len(self.predictors) == 1:
            return (
                "Lift of predictor "
                + self.predictors[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
            )
        else:
            return (
                "Lift of multiple predictors " + " on target " + self.targets[0][0] + " on sample " + self.samples[0][1]
            )


# import Calculator

# expect only one sample
# expects only one target variable
# expects one or more predictors


class PredictorROCCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictors = self.predictors
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        # if the predictor is categorical one, encode it with badrate first
        for predictor in predictors:
            if df[predictor].dtype == "O":
                df_piv = pd.pivot_table(
                    df, index=predictor, columns=target[0], values=rowid_col, aggfunc=len, fill_value=0
                )
                df_piv["br"] = df_piv.apply(lambda x: 1.00 * x[1] / (x[0] + x[1]), axis=1)
                df_piv = pd.DataFrame(df_piv.reset_index().values, columns=[predictor, "goods", "bads", "br"])
                df = (
                    df[[rowid_col, time_variable, target[0], target[1]] + predictors]
                    .copy()
                    .reset_index()
                    .merge(df_piv, on=predictor, how="left")
                    .set_index("index")
                )
                df[predictor] = df["br"]

        # prepare combinations of predictor and target
        arr = []
        from sklearn.metrics import roc_curve

        for predictor in predictors:

            fpr, tpr, cutoff = roc_curve(df[df[target[1]] == 1][target[0]], df[df[target[1]] == 1][predictor])
            auc = pd.DataFrame(
                [
                    pd.Series(fpr, name="False positive rate"),
                    pd.Series(tpr, name="True positive rate"),
                    pd.Series(cutoff, name="Cutoff"),
                ]
            ).T
            auc.columns = pd.MultiIndex.from_product([[predictor], auc.columns])
            arr.append(auc)

        # return final reults
        # print(auc)
        self.table = pd.concat(arr, axis=1, sort=False)
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        for predictor in self.predictors:
            plt.plot(
                self.get_table()[predictor]["False positive rate"],
                self.get_table()[predictor]["True positive rate"],
                label=predictor,
            )

        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.plot([0, 1], [0, 1], color="grey", lw=2, linestyle="--")
        plt.title("ROC")
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        plt.legend(loc="lower right")

        plt.show()
        return self

    def get_description(self):
        if len(self.predictors) == 1:
            return (
                "Gini of predictor "
                + self.predictors[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
            )
        else:
            return (
                "Gini of multiple predictors " + " on target " + self.targets[0][0] + " on sample " + self.samples[0][1]
            )


# import Calculator

# expect only one sample
# expects only one target variable
# expects only one predictor


class GroupingEvaluationCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        self.pr = PredictorRiskInTimeCalculator(self.projectParameters)

        self.pr.samples = self.samples
        self.pr.targets = self.targets
        self.pr.predictors = self.predictors
        self.pr.rowid_variable = self.rowid_variable
        self.pr.time_variable = self.time_variable
        self.pr.weight = self.weight

        self.ps = PredictorShareInTimeCalculator(self.projectParameters)

        self.ps.samples = self.samples
        self.ps.targets = self.targets
        self.ps.predictors = self.predictors
        self.ps.rowid_variable = self.rowid_variable
        self.ps.time_variable = self.time_variable
        self.ps.weight = self.weight

        self.pg = PredictorGiniInTimeCalculator(self.projectParameters)

        self.pg.samples = self.samples
        self.pg.targets = self.targets
        self.pg.predictors = self.predictors
        self.pg.rowid_variable = self.rowid_variable
        self.pg.time_variable = self.time_variable
        self.pg.weight = self.weight

        if self.weight:
            self.pr.calculate_weighted()
            self.ps.calculate_weighted()
            self.pg.calculate_weighted()
        else:
            self.pr.calculate()
            self.ps.calculate()
            self.pg.calculate()

        self.table = pd.concat([self.pr.get_table(), self.ps.get_table(), self.pg.get_table()], axis=1, sort=False)
        return self

    def get_table(self):
        return self.table

    def get_visualization(self, output_folder=None):
        from matplotlib import pyplot as plt

        fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(20, 4))

        badrate = self.pr.table["Bad rate"]
        del badrate["All"]
        badrate = badrate.drop("All")
        badrate.index = badrate.index.astype(str)
        yaxislim = math.ceil(1.2 * badrate.max().max() * 40) / 40
        badrate.plot(
            ylim=(0, yaxislim),
            title="Risk of " + self.pr.predictors[0] + " on " + self.pr.targets[0][0],
            ax=axes[0],
            use_index=True,
        )
        axes[0].set_xticks(list(np.arange(badrate.shape[0])))
        axes[0].set_xticklabels(badrate.index)
        h, l = axes[0].get_legend_handles_labels()

        if self.grouping:
            try:
                l = [self.replace_legend(float(i), self.pr.predictors[0], self.grouping) for i in l]
            except:
                pass
        else:    
            try:
                l = [f"{float(i):6.3f}" for i in l]
            except:
                pass
        axes[0].legend(h, l, bbox_to_anchor=(-0.08, 0.5), loc="right")

        share = self.ps.table["Share"]
        del share["All"]
        share = share.drop("All")
        share.index = share.index.astype(str)
        share.plot(ylim=(0, 1), title="Share of " + self.pr.predictors[0], ax=axes[1])
        axes[1].set_xticks(list(np.arange(share.shape[0])))
        axes[1].set_xticklabels(share.index)
        axes[1].get_legend().remove()

        gini = self.pg.table
        gini = gini.drop("All")
        gini.index = gini.index.astype(str)
        gini.plot(title="Gini of " + self.predictors[0] + " on " + self.targets[0][0], ylim=(0, 100), ax=axes[2])
        axes[2].set_xticks(list(np.arange(gini.shape[0])))
        axes[2].set_xticklabels(gini.index)
        axes[2].get_legend().remove()

        if output_folder:
            plt.savefig(path.join(output_folder,f"{self.predictors[0]}.PNG"), bbox_inches='tight', dpi = 72)

        plt.show()
        return self

    def get_description(self):
        return (
            "Grouping evaluation of predictor "
            + self.predictors[0]
            + " on target "
            + self.targets[0][0]
            + " on sample "
            + self.samples[0][1]
        )


# import Calculator

# expect only one sample
# expects only one target variable
# expects only one predictor


class ContinuousEvaluationCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        self.pr = PredictorLogriskInTimeCalculator(self.projectParameters)

        self.pr.samples = self.samples
        self.pr.targets = self.targets
        self.pr.predictors = self.predictors
        self.pr.rowid_variable = self.rowid_variable
        self.pr.time_variable = self.time_variable
        self.pr.calculate()

        self.ps = PredictorStatsInTimeCalculator(self.projectParameters)

        self.ps.samples = self.samples
        self.ps.targets = self.targets
        self.ps.predictors = self.predictors
        self.ps.rowid_variable = self.rowid_variable
        self.ps.time_variable = self.time_variable
        self.ps.calculate()

        self.pg = PredictorGiniInTimeCalculator(self.projectParameters)

        self.pg.samples = self.samples
        self.pg.targets = self.targets
        self.pg.predictors = self.predictors
        self.pg.rowid_variable = self.rowid_variable
        self.pg.time_variable = self.time_variable
        self.pg.calculate()

        self.ph = PredictorHistogramCalculator(self.projectParameters)

        self.ph.samples = self.samples
        self.ph.targets = self.targets
        self.ph.predictors = self.predictors
        self.ph.rowid_variable = self.rowid_variable
        self.ph.time_variable = self.time_variable
        self.ph.calculate()

        self.pm = MissingInTimeCalculator(self.projectParameters)

        self.pm.samples = self.samples
        self.pm.targets = self.targets
        self.pm.predictors = self.predictors
        self.pm.rowid_variable = self.rowid_variable
        self.pm.time_variable = self.time_variable
        self.pm.calculate()

        self.table = pd.concat(
            [self.pr.get_table(), self.ps.get_table(), self.pm.get_table()[["Share", "Bad rate"]], self.pg.get_table()],
            axis=1,
            sort=False,
        )
        return self

    def get_table(self):
        return self.table

    def get_visualization(self, output_folder=None):
        from matplotlib import pyplot as plt

        fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(20, 4))

        # a = self.pr.get_table()["Logrisk on bin"]
        # a = a.drop('All')
        # a.index = a.index.astype(str)
        # a.T.plot(title="Logisk of " + self.pr.predictors[0] + " on " + self.pr.targets[0][0], ax=axes[0])
        # axes[0].set_xticks(list(np.arange(a.T.shape[0])))
        # axes[0].set_xticklabels(a.T.index)

        b = self.ps.get_table()
        b = b.drop("All")
        b.index = b.index.astype(str)
        b["Statistics"][["mean", "25%", "50%", "75%", "90%"]].plot(title="Quantiles " + self.predictors[0], ax=axes[0])
        axes[0].legend(bbox_to_anchor=(-0.08, 0.5), loc="right")
        # axes[1].set_xticks(list(np.arange(b.shape[0])))
        # axes[1].set_xticklabels(b.index)

        gini = self.pg.table
        gini = gini.drop("All")
        gini.index = gini.index.astype(str)
        gini.plot(title="Gini of " + self.predictors[0] + " on " + self.targets[0][0], ylim=(0, 100), ax=axes[2])
        # axes[3].set_xticks(list(np.arange(gini.shape[0])))
        # axes[3].set_xticklabels(gini.index)

        # self.ph.get_table().plot(kind="bar", title="Distribution", color="blue", width=1, ax=axes[3])
        # plt.xticks([], [])

        ax1 = axes[1]
        ax2 = ax1.twinx()

        ax1.set_ylabel("Risk")
        ax2.set_ylabel("Share")

        try:
            risk = pd.DataFrame(self.table["Bad rate"]["Missing"])
            risk.columns = ["Risk of missings"]
            risk = risk.drop("All")
            risk.index = risk.index.astype(str)

            risk.plot(ax=ax1, ylim=(0, 1), color="orange", linestyle="dashed")

            share = pd.DataFrame(self.table["Share"]["Missing"])
            share.columns = ["Share of missings"]
            share = share.drop("All")
            share.index = share.index.astype(str)
            share.plot(ax=ax2, ylim=(0, 1), color="orange", title="Share and risk of missings")

            # ax2.set_xticks(list(np.arange(share.shape[0])))
            # ax2.set_xticklabels(share.index)
        except:
            None

        try:
            share = pd.DataFrame(self.table["Share"]["Not missing"])
            share.columns = ["Share of non missings"]
            share = share.drop("All")
            share.index = share.index.astype(str)
            share.plot(ax=ax2, ylim=(0, 1), color="grey", title="Share and risk of missings")

            risk = pd.DataFrame(self.table["Bad rate"]["Not missing"])
            risk.columns = ["Risk of non missings"]
            risk = risk.drop("All")
            risk.index = risk.index.astype(str)
            risk.plot(ax=ax1, ylim=(0, 1), color="grey", linestyle="dashed")

            # ax1.set_xticks(list(np.arange(risk.shape[0])))
            # ax1.set_xticklabels(risk.index)
        except:
            None

        ax1.legend(loc=4)
        ax2.legend(loc=0)

        if output_folder:
            plt.savefig(path.join(output_folder,f"{self.predictors[0]}.PNG"), bbox_inches='tight', dpi = 72)

        plt.show()

        return self

    def get_description(self):
        return (
            "Evaluation of "
            + self.predictors[0]
            + " on target "
            + self.targets[0][0]
            + " on sample "
            + self.samples[0][1]
        )


# import Calculator

# expect only one sample
# expects only one target variable
# expects multi predictor


class ScoreComparisonCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        self.pg = PredictorGiniInTimeCalculator(self.projectParameters)

        self.pg.samples = self.samples
        self.pg.targets = self.targets
        self.pg.predictors = self.predictors
        self.pg.rowid_variable = self.rowid_variable
        self.pg.time_variable = self.time_variable
        self.pg.calculate()

        self.ph = PredictorLiftInTimeCalculator(self.projectParameters)
        self.ph.samples = self.samples
        self.ph.targets = self.targets
        self.ph.predictors = self.predictors
        self.ph.rowid_variable = self.rowid_variable
        self.ph.time_variable = self.time_variable
        self.ph.calculate()

        self.sdc = SampleDescriptionCalculator(self.projectParameters)

        self.sdc.samples = self.samples
        self.sdc.targets = self.targets
        self.sdc.predictors = self.predictors
        self.sdc.rowid_variable = self.rowid_variable
        self.sdc.time_variable = self.time_variable
        self.sdc.calculate()

        self.plc = PredictorLiftCalculator(self.projectParameters)

        self.plc.samples = self.samples
        self.plc.targets = self.targets
        self.plc.predictors = self.predictors
        self.plc.rowid_variable = self.rowid_variable
        self.plc.time_variable = self.time_variable
        self.plc.calculate()

        self.procc = PredictorROCCalculator(self.projectParameters)

        self.procc.samples = self.samples
        self.procc.targets = self.targets
        self.procc.predictors = self.predictors
        self.procc.rowid_variable = self.rowid_variable
        self.procc.time_variable = self.time_variable
        self.procc.calculate()

        self.table = pd.concat([self.sdc.get_table(), self.pg.get_table(), self.ph.get_table()], axis=1, sort=False)
        return self

    def get_table(self):
        return self.table

    def get_visualization(self, output_folder=None, filename=None):
        from matplotlib import pyplot as plt

        fig, axes = plt.subplots(nrows=1, ncols=4, figsize=(25, 5))

        gini = self.pg.table
        gini = gini.drop("All")
        gini.index = gini.index.astype(str)
        gini.plot(title="Gini of " + self.predictors[0] + " on " + self.targets[0][0], ylim=(0, 100), ax=axes[0])
        # axes[0].set_xticks(list(np.arange(gini.shape[0])))
        # axes[0].set_xticklabels(gini.index)

        lift = self.ph.get_table()
        lift = lift.drop("All")
        lift.index = lift.index.astype(str)
        lift.plot(title="Lift10 of " + self.predictors[0] + " on " + self.targets[0][0], ylim=(0, 7), ax=axes[1])
        # axes[1].set_xticks(list(np.arange(lift.shape[0])))
        # axes[1].set_xticklabels(lift.index)

        lift_static = self.plc.get_table()
        lift_static.plot(title="Lift of " + self.predictors[0] + " on " + self.targets[0][0], ax=axes[2])
        axes[2].set_xticks(list(np.arange(lift_static.shape[0])))
        axes[2].set_xticklabels(lift_static.index)

        roc = self.procc.get_table()
        for predictor in self.predictors:
            plt.plot(
                roc[predictor]["False positive rate"],
                roc[predictor]["True positive rate"],
                label=predictor,
                axes=axes[3],
                marker="None",
            )

        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.plot([0, 1], [0, 1], color="grey", lw=2, linestyle="--")
        plt.title("ROC")
        plt.xlabel("False Positive Rate")
        plt.ylabel("True Positive Rate")
        plt.legend(loc="lower right")

        if output_folder:
            if not filename:
                filename = "score_comparison.PNG"

            plt.savefig(path.join(output_folder,filename), bbox_inches='tight', dpi = 72)

        plt.show()
        return self

    def get_description(self):
        return "Comparison of scores" + " on target " + self.targets[0][0] + " on sample " + self.samples[0][1]


# Matus adjusted - Score by segments calculator
class ScoreSegmentsCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictor = self.predictors[0]
        segment = self.segments[0]
        rowid_col = self.rowid_variable
        segment = self.segments[0]
        # ---------------------------------

        self.pg = PredictorGiniBySegmentsCalculator(self.projectParameters)  # done

        self.pg.samples = self.samples
        self.pg.targets = self.targets
        self.pg.predictors = self.predictors
        self.pg.rowid_variable = self.rowid_variable
        self.pg.segments = self.segments
        self.pg.calculate()

        self.ph = PredictorLiftBySegmentsCalculator(self.projectParameters)  # done
        self.ph.samples = self.samples
        self.ph.targets = self.targets
        self.ph.predictors = self.predictors
        self.ph.rowid_variable = self.rowid_variable
        self.ph.segments = self.segments
        self.ph.calculate()

        self.sdc = SampleDescriptionSegmentsCalculator(self.projectParameters)  # done

        self.sdc.samples = self.samples
        self.sdc.targets = self.targets
        self.sdc.predictors = self.predictors
        self.sdc.rowid_variable = self.rowid_variable
        self.sdc.segments = self.segments
        self.sdc.calculate()

        self.table = pd.concat([self.sdc.get_table(), self.pg.get_table(), self.ph.get_table()], axis=1, sort=False)
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        fig, axes = plt.subplots(nrows=1, ncols=3, figsize=(20, 6))

        targets = self.targets
        predictors = self.predictors
        segments = self.segments

        desc = self.sdc.get_table()["Sample description"][[targets[0][0] + " measurable", targets[0][0] + " bads"]]
        desc[targets[0][0] + " goods"] = desc[targets[0][0] + " measurable"] - desc[targets[0][0] + " bads"]
        desc = desc.drop("All")
        N = desc.shape[0]

        avg_scores = self.sdc.get_table()["Sample description"][
            [targets[0][0] + " default rate"]
            + ["AVG(" + predictor + ") on " + targets[0][0] + " meas." for predictor in predictors]
        ]
        avg_scores = avg_scores.drop("All")

        ind = np.arange(N)  # the x locations for the groups
        width = 0.25  # the width of the bars: can also be len(x) sequence

        ax1 = fig.axes[0]
        ax1.bar(ind, desc[targets[0][0] + " bads"], width, color="tomato", label="Bads")
        ax1.bar(
            ind,
            desc[targets[0][0] + " goods"],
            width,
            bottom=desc[targets[0][0] + " bads"],
            color="skyblue",
            label="Goods",
        )
        ax1.set_ylabel("Count of measurable cases")
        ax1.set_xlabel(segments[0])
        ax1.set_xticks(ind)
        ax1.set_xticklabels(desc.index)

        ax2 = ax1.twinx()
        yaxislim = math.ceil(1.4 * avg_scores.max().max() * 40) / 40
        ax2.set_ylim([0, yaxislim])
        ax2.plot(ind, avg_scores[targets[0][0] + " default rate"], label="Default rate")
        for predictor in predictors:
            ax2.plot(
                ind, avg_scores["AVG(" + predictor + ") on " + targets[0][0] + " meas."], label="AVG(" + predictor + ")"
            )

        ax1.set_title("Calibration on " + targets[0][0])
        ax1.legend(loc="upper left")
        ax2.legend(loc="upper right")

        gini = self.pg.get_table()
        gini = gini.drop("All")
        ax3 = fig.axes[1]

        width = 0.15

        for i in np.arange(len(self.predictors)):
            ax3.bar(
                ind + width * (2 * i - len(self.predictors) + 1) / 2,
                gini["Gini " + self.targets[0][0]][predictors[i]],
                width=width,
                label=predictors[i],
            )

        ax3.set_title("Gini of predictors on " + self.targets[0][0])
        ax3.set_ylim(0, 100)
        ax3.set_xlabel(segments[0])
        ax3.set_xticks(ind)
        ax3.set_xticklabels(desc.index)
        ax3.legend(loc="upper right")

        lift = self.ph.get_table()
        lift = lift.drop("All")

        ax4 = fig.axes[2]

        width = 0.15

        for i in np.arange(len(self.predictors)):
            ax4.bar(
                ind + width * (2 * i - len(self.predictors) + 1) / 2,
                lift["Lift10"][predictors[i]],
                width=width,
                label=predictors[i],
            )

        ax4.set_title("Lift10 of predictors on " + self.targets[0][0])
        ax4.set_ylim(0, 6)
        ax4.set_xlabel(segments[0])
        ax4.set_xticks(ind)
        ax4.set_xticklabels(desc.index)
        ax4.legend(loc="upper right")

        for ax in fig.axes:
            for tick in ax.get_xticklabels():
                tick.set_rotation(90)

        fig.subplots_adjust(wspace=0.3)

        for ax in axes.flatten():
            for label in ax.get_xticklabels():
                label.set_rotation(45)

        plt.show()

        return self

    def get_description(self):
        return (
            "Comparison of scores"
            + " on target "
            + self.targets[0][0]
            + " on sample "
            + self.samples[0][1]
            + " by segments of "
            + self.segments[0]
        )


# import Calculator

# expect only one sample
# expects only one predictor


class PredictorStatsInTimeCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        b = df[[predictor]].describe(percentiles=[0.1, 0.25, 0.5, 0.75, 0.9]).T
        b.set_index(pd.MultiIndex.from_product([["All"]]), inplace=True)

        a = (
            df[[time_variable, predictor]]
            .groupby(time_variable)[predictor]
            .describe(percentiles=[0.1, 0.25, 0.5, 0.75, 0.9])
        )
        # print(a)
        # a = a.reset_index()
        # a = a.rename(columns={'level_1':'statistics'})
        # print(a)
        # res = pd.pivot_table(a, index=time_variable, columns='statistics',values=predictor, aggfunc=np.max)
        res = a[b.columns]

        self.table = pd.concat([res, b], axis=0, sort=False)
        self.table.index.name = time_variable
        self.table.columns = pd.MultiIndex.from_product([["Statistics"], res.columns])

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        a = self.table
        a.drop("All")
        ax = a["Statistics"][["mean", "std"]].plot(title="Mean and standard deviation of " + self.predictors[0])
        ax.set_xticks(list(np.arange(a["Statistics"][["mean", "std"]].shape[0])))
        ax.set_xticklabels(a["Statistics"][["mean", "std"]].index)
        plt.show()
        return self

    def get_description(self):
        return "Statistics of predictor " + self.predictors[0] + " on sample " + self.samples[0][1]


# import Calculator

# expect only one sample
# expects only one predictor


class PredictorHistogramCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        self.table = pd.cut(df[predictor], bins=100).value_counts().sort_index(ascending=True)
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        ax = self.samples[0][0][self.predictors[0]].plot(
            kind="hist", bins=100, title="Distribution of " + self.predictors[0]
        )
        ax.set_xticks(list(np.arange(self.samples[0][0][self.predictors[0]].shape[0])))
        ax.set_xticklabels(self.samples[0][0][self.predictors[0]].index)

        plt.show()
        return self

    def get_description(self):
        return "Histogram of predictor " + self.predictors[0] + " on sample " + self.samples[0][1]


# import Calculator

# expect only one sample
# expects only one target
# expects one predictor


class PredictorLogriskInTimeCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        target = self.targets[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        df = df.copy()

        # ri = RussianImputer().fit(df[df[target[1]] == 1][predictor], df[df[target[1]] == 1][target[0]])
        # df[predictor] = ri.transform(df[predictor])

        # if df[df[target[1]]==1][predictor].value_counts().shape[0]<=10:
        #    a = df[df[target[1]]==1][predictor]
        # else:
        try:
            a = pd.cut(df[df[target[1]] == 1][predictor], bins=5, labels=False)
        except:
            try:
                a = pd.cut(df[df[target[1]] == 1][predictor], bins=5, labels=False)
            except:
                a = pd.cut(df[df[target[1]] == 1][predictor], bins=2, labels=False)

        gb = df[df[target[1]] == 1][[target[0], time_variable]].groupby([time_variable, a])

        self.table = pd.DataFrame(gb.apply(lambda x: (len(x))))
        self.table = pd.concat([self.table, gb.apply(lambda x: (np.sum(x[target[0]])))], axis=1, sort=False)
        self.table = pd.concat([self.table, gb.apply(lambda x: (np.mean(x[target[0]])))], axis=1, sort=False)
        self.table.columns = ["Meas. obs. on bin", "Bads on bin", "Risk on bin"]
        self.table["Logrisk on bin"] = self.table["Risk on bin"].apply(
            lambda p: -np.inf if p == 1 else np.log(p / (1 - p))
        )

        gb_nt = df[df[target[1]] == 1][[target[0], time_variable]].groupby([a])

        gb_nt_a = pd.DataFrame(gb_nt.apply(lambda x: (len(x))))
        gb_nt_a = pd.concat([gb_nt_a, gb_nt.apply(lambda x: (np.sum(x[target[0]])))], axis=1, sort=False)
        gb_nt_a = pd.concat([gb_nt_a, gb_nt.apply(lambda x: (np.mean(x[target[0]])))], axis=1, sort=False)
        gb_nt_a.columns = ["Meas. obs. on bin", "Bads on bin", "Risk on bin"]
        gb_nt_a["Logrisk on bin"] = gb_nt_a["Risk on bin"].apply(lambda p: -np.inf if p == 1 else np.log(p / (1 - p)))

        gb_nt_a.set_index(pd.MultiIndex.from_product([["All"], gb_nt_a.index.values]), inplace=True)

        self.table = pd.concat([self.table, gb_nt_a], axis=0, sort=False)

        return self

    def get_table(self):
        return self.table.unstack()

    def get_visualization(self):
        import matplotlib.pyplot as plt

        # self.get_table()['logrisk'].plot( title='Association of '+ self.predictors[0] + ' with logrisk')
        # self.get_table()['risk'].plot( title='Association of '+ self.predictors[0] + ' with risk')
        ax = self.table["Risk on bin"].unstack().T.plot()
        ax.set_xticks(list(np.arange(self.table["Risk on bin"].unstack().T.shape[0])))
        ax.set_xticklabels(self.table["Risk on bin"].unstack().T.index)
        plt.show()
        return self

    # def get_calculator_parameters(self):
    #     return self.calculatorParameters

    def get_description(self):
        return (
            "Logrisk in time of predictor "
            + self.predictors[0]
            + " on target "
            + self.targets[0][0]
            + " on sample "
            + self.samples[0][1]
        )


# import Calculator

# expect only one sample
# expects only one target
# expects one predictor


class PredictorLogriskCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        target = self.targets[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        if df[df[target[1]] == 1][predictor].value_counts().shape[0] <= 10:
            a = df[df[target[1]] == 1][predictor]
        else:
            try:
                a = pd.qcut(df[df[target[1]] == 1][predictor], q=10)
            except:
                a = pd.qcut(df[df[target[1]] == 1][predictor], q=5)

        gb = df[df[target[1]] == 1][[target[0], time_variable]].groupby([a])
        self.table = pd.DataFrame(gb.apply(lambda x: (len(x))))
        self.table = pd.concat([self.table, gb.apply(lambda x: (np.sum(x[target[0]])))], axis=1, sort=False)
        self.table = pd.concat([self.table, gb.apply(lambda x: (np.mean(x[target[0]])))], axis=1, sort=False)
        self.table.columns = ["cnt", "bads", "risk"]
        self.table["logrisk"] = self.table["risk"].apply(lambda p: np.log(p / (1 - p)))
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        # self.get_table()['logrisk'].plot( title='Association of '+ self.predictors[0] + ' with logrisk')
        # self.get_table()['risk'].plot( title='Association of '+ self.predictors[0] + ' with risk')
        ax = self.table["logrisk"].plot()
        ax.set_xticks(list(np.arange(self.table["logrisk"].shape[0])))
        ax.set_xticklabels(self.table["logrisk"].index)
        plt.show()
        return self

    def get_description(self):
        return (
            "Logrisk of predictor "
            + self.predictors[0]
            + " on target "
            + self.targets[0][0]
            + " on sample "
            + self.samples[0][1]
        )


# expect list of at least 2 samples (i.e. a sample is a tuple of the form (dataset,dataset's_name)) with the convention that first sample in the list is the train sample and second sample is the test sample
# expects only one target variable (i.e. a tuple of the form (target_column, target's_name))
# expects all predictors of the proposed model
# expects one score, the proposed model's score, with the expectation that it is the first one in list of scores


class MarginalContributionsCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        #
        # -----------------------------------------
        samples = self.samples
        target = self.targets
        predictors = [pred for pred in self.predictors if "WOE" in pred]
        proposed_score = self.scores[0]
        # ---------------------------------

        # calculating the tuple of Ginis of the whole proposed model
        from sklearn import metrics
        from sklearn import linear_model

        lg = linear_model.LogisticRegression(solver="lbfgs")

        t = ("Nothing is removed",)

        for sample, name in samples:
            for tgt_col, tgt_obs in target:
                df = sample.loc[sample[tgt_obs] == 1, :]

                if len(df[tgt_col].unique()) > 1:
                    gini_sample = round(100 * (metrics.roc_auc_score(df[tgt_col], df[proposed_score]) * 2 - 1), 2)
                else:
                    gini_sample = float("NaN")

                t += (gini_sample,)

        self.table = [t]

        # calculating the tuples of Ginis of the submodels
        for pred in predictors:
            if pred != "Intercept":

                # defining training dataset
                df = samples[0][0]
                df = df.loc[df[target[0][1]] == 1, :]
                df["Intercept"] = 1

                # fitting model without one predictor on the training dataset
                res = lg.fit(df[list(set(predictors + ["Intercept"]) - set([pred]))], df[target[0][0]])

                # creating and filling a tuple
                t = (pred,)

                for sample, name in samples:
                    for tgt_col, tgt_obs in target:

                        df = sample.loc[sample[tgt_obs] == 1, :]
                        df["Intercept"] = 1
                        if len(df[tgt_col].unique()) > 1:
                            gini_sample = round(
                                100
                                * (
                                    metrics.roc_auc_score(
                                        df[tgt_col],
                                        res.predict_proba(df[list(set(predictors + ["Intercept"]) - set([pred]))])[
                                            :, 1
                                        ],
                                    )
                                    * 2
                                    - 1
                                ),
                                2,
                            )
                        else:
                            gini_sample = float("NaN")

                        t += (gini_sample,)

            # appending the tuple to the table
            self.table.append(t)

        # polishing the table
        self.table = pd.DataFrame(self.table)
        self.table = self.table.rename(columns={0: "PREDICTOR REMOVED"})
        self.table = self.table.set_index("PREDICTOR REMOVED")
        self.table.columns = pd.MultiIndex.from_product(
            [[name for sample, name in samples], [tgt_name for tgt_name, meas in self.targets]]
        )

        # self.table.columns = ['Predictor removed'] + [name+':'+tgt_col for sample,name in samples for tgt_col,tgt_name in target]
        self.table = self.table.sort_values(by=self.table.columns[1], ascending=False)

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        return self

    def get_description(self):
        return "Marginal contributions of predictors."


# Adjusted by Matus
class MarginalContributionsAddCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        #
        # -----------------------------------------
        samples = self.samples
        target = self.targets
        predictors = self.predictors
        predictors_to_add = self.predictors_to_add
        proposed_score = self.scores[0]
        # ---------------------------------

        # calculating the tuple of Ginis of the whole proposed model
        from sklearn import metrics
        from sklearn import linear_model

        lg = linear_model.LogisticRegression()

        t = ("Nothing is added",)

        for sample, name in samples:
            for tgt_col, tgt_obs in target:
                df = sample.loc[sample[tgt_obs] == 1, :]

                if len(df[tgt_col].unique()) > 1:
                    gini_sample = round(100 * (metrics.roc_auc_score(df[tgt_col], df[proposed_score]) * 2 - 1), 2)
                else:
                    gini_sample = float("NaN")

                t += (gini_sample,)

        base_model = [t]
        self.table = []

        # calculating the tuples of Ginis of the submodels
        for pred in predictors_to_add:
            # defining training dataset
            df = samples[0][0]
            df = df.loc[df[target[0][1]] == 1, :]
            df["Intercept"] = 1

            # fitting model without one predictor on the training dataset
            res = lg.fit(df[predictors + ["Intercept"] + [pred]], df[target[0][0]])

            # creating and filling a tuple
            t = (pred,)
            for sample, name in samples:
                for tgt_col, tgt_obs in target:

                    df = sample.loc[sample[tgt_obs] == 1, :]
                    df["Intercept"] = 1

                    if len(df[tgt_col].unique()) > 1:
                        gini_sample = round(
                            100
                            * (
                                metrics.roc_auc_score(
                                    df[tgt_col], res.predict_proba(df[predictors + ["Intercept"] + [pred]])[:, 1]
                                )
                                * 2
                                - 1
                            ),
                            2,
                        )
                    else:
                        gini_sample = float("NaN")

                    t += (gini_sample,)

            # appending the tuple to the table
            self.table.append(t)

        # polishing the table
        base_model = pd.DataFrame(base_model)
        base_model = base_model.rename(columns={0: "PREDICTOR ADDED"})
        base_model = base_model.set_index("PREDICTOR ADDED")
        base_model.columns = pd.MultiIndex.from_product(
            [[name for sample, name in samples], [tgt_name for tgt_name, meas in self.targets]]
        )

        self.table = pd.DataFrame(self.table)
        self.table = self.table.rename(columns={0: "PREDICTOR ADDED"})
        self.table = self.table.set_index("PREDICTOR ADDED")
        self.table.columns = pd.MultiIndex.from_product(
            [[name for sample, name in samples], [tgt_name for tgt_name, meas in self.targets]]
        )

        # self.table.columns = ['Predictor removed'] + [name+':'+tgt_col for sample,name in samples for tgt_col,tgt_name in target]
        self.table.sort_values(by=self.table.columns[0], inplace=True, ascending=False)

        frames = [base_model, self.table]
        self.table = pd.concat(frames, sort=False)

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        return self

    def get_description(self):
        return "Marginal contributions of predictors."


class MarginalLiftsCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        #
        # -----------------------------------------
        samples = self.samples
        target = self.targets
        predictors = self.predictors
        proposed_score = self.scores[0]
        # ---------------------------------

        def liftN_loc(target_, prediction_, q):

            dframe = pd.DataFrame([pd.Series(target_, name="target"), pd.Series(prediction_, name="prediction")]).T
            # print(dframe)
            quant_ = dframe["prediction"].quantile(q)
            pop_dr = dframe["target"].mean()
            q_dr = dframe["target"][dframe["prediction"] > quant_].mean()
            if pop_dr == 0:
                return np.nan
            else:
                lift = 1.0 * q_dr / pop_dr
                return lift

        # calculating the tuple of Ginis of the whole proposed model
        from sklearn import metrics
        from sklearn import linear_model

        lg = linear_model.LogisticRegression()

        t = ("Nothing is removed",)

        for sample, name in samples:
            for tgt_col, tgt_obs in target:
                df = sample.loc[sample[tgt_obs] == 1, :]

                if len(df[tgt_col].unique()) > 1:
                    lift_sample = round(liftN_loc(df[tgt_col], df[proposed_score], 0.9), 5)
                else:
                    lift_sample = float("NaN")

                t += (lift_sample,)

        self.table = [t]

        # calculating the tuples of Ginis of the submodels
        for pred in predictors:
            if pred != "Intercept":

                # defining training dataset
                df = samples[0][0]
                df = df.loc[df[target[0][1]] == 1, :]
                df["Intercept"] = 1

                # fitting model without one predictor on the training dataset
                res = lg.fit(df[list(set(predictors + ["Intercept"]) - set([pred]))], df[target[0][0]])

                # creating and filling a tuple
                t = (pred,)

                for sample, name in samples:
                    for tgt_col, tgt_obs in target:

                        dframe = sample.loc[sample[tgt_obs] == 1, :].reset_index().drop(["index"], axis=1)

                        if len(dframe[tgt_col].unique()) > 1:
                            lift_sample = round(
                                liftN_loc(
                                    dframe[tgt_col],
                                    res.predict_proba(dframe[list(set(predictors + ["Intercept"]) - set([pred]))])[
                                        :, 1
                                    ],
                                    0.9,
                                ),
                                5,
                            )
                        else:
                            lift_sample = float("NaN")

                        t += (lift_sample,)

            # appending the tuple to the table
            self.table.append(t)

        # polishing the table
        self.table = pd.DataFrame(self.table)
        self.table = self.table.rename(columns={0: "PREDICTOR REMOVED"})
        self.table = self.table.set_index("PREDICTOR REMOVED")
        self.table.columns = pd.MultiIndex.from_product(
            [[name for sample, name in samples], [tgt_name for tgt_name, meas in self.targets]]
        )

        # self.table.columns = ['Predictor removed'] + [name+':'+tgt_col for sample,name in samples for tgt_col,tgt_name in target]
        self.table = self.table.sort_values(by=self.table.columns[1], ascending=False)

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        return self

    def get_description(self):
        return "Marginal contributions of predictors."


# expects one sample
# expects all predictors of the proposed model


class CorrelationCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        #
        # -----------------------------------------
        samples = self.samples
        target = self.targets
        predictors = self.predictors
        df = samples[0][0]
        # ---------------------------------

        self.table = df[predictors].corr(method="spearman")

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        return self

    def get_description(self):
        return "Correlation matrix on" + self.samples[0][0]


# expects one sample
# expects two scores


class TransitionCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        #
        # -----------------------------------------
        samples = self.samples
        target = self.targets
        predictors = self.predictors
        df = samples[0][0]

        # ---------------------------------

        scoreA = self.scores[0]
        scoreB = self.scores[1]
        dfx = df.copy()
        dfx[scoreA + "_bin"] = pd.qcut(dfx[scoreA], q=5)
        dfx[scoreB + "_bin"] = pd.qcut(dfx[scoreB], q=5)
        self.table = pd.pivot_table(
            dfx,
            index=scoreA + "_bin",
            columns=dfx[scoreB + "_bin"],
            aggfunc=len,
            values=self.projectParameters.rowid_variable,
            dropna=False,
            fill_value=0,
        )

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        return self

    def get_description(self):
        return "Transition matrix from " + self.scores[1] + " to " + self.scores[0] + " on " + self.samples[0][1]


class XgbPredictorEvaluationCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        target = self.targets[0]
        predictor = self.predictors[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        self.pr = PredictorLogriskInTimeCalculator(self.projectParameters)

        self.pr.samples = self.samples
        self.pr.targets = self.targets
        self.pr.predictors = self.predictors
        self.pr.rowid_variable = self.rowid_variable
        self.pr.time_variable = self.time_variable
        self.pr.calculate()

        self.ps = PredictorStatsInTimeCalculator(self.projectParameters)

        self.ps.samples = self.samples
        self.ps.targets = self.targets
        self.ps.predictors = self.predictors
        self.ps.rowid_variable = self.rowid_variable
        self.ps.time_variable = self.time_variable
        self.ps.calculate()

        self.pg = PredictorGiniInTimeCalculator(self.projectParameters)

        self.pg.samples = self.samples
        self.pg.targets = self.targets
        self.pg.predictors = self.predictors
        self.pg.rowid_variable = self.rowid_variable
        self.pg.time_variable = self.time_variable
        self.pg.calculate()

        self.ph = PredictorHistogramCalculator(self.projectParameters)

        self.ph.samples = self.samples
        self.ph.targets = self.targets
        self.ph.predictors = self.predictors
        self.ph.rowid_variable = self.rowid_variable
        self.ph.time_variable = self.time_variable
        self.ph.calculate()

        self.ipc = IceplotCalculator(self.projectParameters)
        self.ipc.samples = self.samples
        self.ipc.predictors = self.predictors
        self.ipc.calculate()

        self.pm = MissingInTimeCalculator(self.projectParameters)
        self.pm.samples = self.samples
        self.pm.targets = self.targets
        self.pm.predictors = self.predictors
        self.pm.rowid_variable = self.rowid_variable
        self.pm.time_variable = self.time_variable
        self.pm.calculate()

        self.table = pd.concat(
            [self.pr.get_table(), self.ps.get_table(), self.pm.get_table()[["Share", "Bad rate"]], self.pg.get_table()],
            axis=1,
            sort=False,
        )
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        from matplotlib import pyplot as plt

        fig, axes = plt.subplots(nrows=1, ncols=6, figsize=(30, 5))

        a = self.pr.get_table()["Logrisk on bin"]
        # a = a.drop('All')
        a.T.plot(title="Logisk of " + self.pr.predictors[0] + " on " + self.pr.targets[0][0], ax=axes[0])
        axes[0].set_xticks(list(np.arange(a.T.shape[0])))
        axes[0].set_xticklabels(a.T.index)

        b = self.ps.get_table()
        b = b.drop("All")
        b["Statistics"][["mean", "25%", "50%", "75%", "90%"]].plot(title="Quantiles " + self.predictors[0], ax=axes[1])
        axes[1].set_xticks(list(np.arange(b["Statistics"][["mean", "25%", "50%", "75%", "90%"]].shape[0])))
        axes[1].set_xticklabels(b["Statistics"][["mean", "25%", "50%", "75%", "90%"]].index)

        gini = self.pg.table
        gini = gini.drop("All")
        gini.plot(title="Gini of " + self.predictors[0] + " on " + self.targets[0][0], ylim=(0, 100), ax=axes[3])
        axes[3].set_xticks(list(np.arange(gini.shape[0])))
        axes[3].set_xticklabels(gini.index)

        self.ph.get_table().plot(kind="bar", title="Distribution", color="blue", width=1, ax=axes[5])
        plt.xticks([], [])

        ax1 = axes[2]
        ax2 = ax1.twinx()

        ax1.set_ylabel("Risk")
        ax2.set_ylabel("Share")

        try:
            risk = pd.DataFrame(self.table["Bad rate"]["Missing"])
            risk.columns = ["Risk of missings"]
            risk = risk.drop("All")
            risk.plot(ax=ax1, ylim=(0, 1), color="orange", linestyle="dashed")

            share = pd.DataFrame(self.table["Share"]["Missing"])
            share.columns = ["Share of missings"]
            share = share.drop("All")
            share.plot(ax=ax2, ylim=(0, 1), color="orange", title="Share and risk of missings")

            ax2.set_xticks(list(np.arange(share.shape[0])))
            ax2.set_xticklabels(share.index)
        except:
            None

        try:
            share = pd.DataFrame(self.table["Share"]["Not missing"])
            share.columns = ["Share of non missings"]
            share = share.drop("All")
            share.plot(ax=ax2, ylim=(0, 1), color="grey", title="Share and risk of missings")

            risk = pd.DataFrame(self.table["Bad rate"]["Not missing"])
            risk.columns = ["Risk of non missings"]
            risk = risk.drop("All")
            risk.plot(ax=ax1, ylim=(0, 1), color="grey", linestyle="dashed")

            ax1.set_xticks(list(np.arange(risk.shape[0])))
            ax1.set_xticklabels(risk.index)
        except:
            None

        ax1.legend(loc=4)
        ax2.legend(loc=0)

        self.ipc.get_table().plot(ax=axes[4], title="Ice plot of " + self.predictors[0])

        plt.show()

        return self

    def get_description(self):
        return (
            "Evaluation of "
            + self.predictors[0]
            + " on target "
            + self.targets[0][0]
            + " on sample "
            + self.samples[0][1]
        )


class MissingInTimeCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        target = self.targets[0]
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        df = df.copy()
        df[predictor] = df[predictor].isnull().apply(lambda x: "Missing" if x == True else "Not missing")
        self.samples[0] = (df, self.samples[0][1])

        self.pr = PredictorRiskInTimeCalculator(self.projectParameters)

        self.pr.samples = self.samples
        self.pr.targets = self.targets
        self.pr.predictors = self.predictors
        self.pr.rowid_variable = self.rowid_variable
        self.pr.time_variable = self.time_variable
        self.pr.calculate()

        self.ps = PredictorShareInTimeCalculator(self.projectParameters)

        self.ps.samples = self.samples
        self.ps.targets = self.targets
        self.ps.predictors = self.predictors
        self.ps.rowid_variable = self.rowid_variable
        self.ps.time_variable = self.time_variable
        self.ps.calculate()

        self.table = pd.concat([self.pr.get_table(), self.ps.get_table()], axis=1, sort=False)

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        fig, ax1 = plt.subplots()

        ax2 = ax1.twinx()

        ax1.set_ylabel("Risk")
        ax2.set_ylabel("Share")

        try:
            risk = pd.DataFrame(self.table["Bad rate"]["Missing"])
            risk.columns = ["Risk of missings"]
            risk = risk.drop("All")
            risk.plot(ax=ax1, ylim=(0, 1), color="orange", linestyle="dashed")

            share = pd.DataFrame(self.table["Share"]["Missing"])
            share.columns = ["Share of missings"]
            share = share.drop("All")
            share.plot(ax=ax2, ylim=(0, 1), color="orange", title="Share and risk of missings")

            ax2.set_xticks(list(np.arange(share.shape[0])))
            ax2.set_xticklabels(share.index)
        except:
            None

        try:
            share = pd.DataFrame(self.table["Share"]["Not missing"])
            share.columns = ["Share of non missings"]
            share = share.drop("All")
            share.plot(ax=ax2, ylim=(0, 1), color="grey", title="Share and risk of missings")

            risk = pd.DataFrame(self.table["Bad rate"]["Not missing"])
            risk.columns = ["Risk of non missings"]
            risk = risk.drop("All")
            risk.plot(ax=ax1, ylim=(0, 1), color="grey", linestyle="dashed")

            ax1.set_xticks(list(np.arange(risk.shape[0])))
            ax1.set_xticklabels(risk.index)
        except:
            None

        ax1.legend(loc=4)
        ax2.legend(loc=0)

        plt.show()

    def get_description(self):
        return 1


# expect one sample, one predictor, no target
# expect a scoring object with function predict_proba


class IceplotCalculator(Calculator):
    def calculate(self):
        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        xgb_model = self.projectParameters.model
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        predictor_stats = df[predictor].describe().T
        # print(predictor_stats)
        predictor_min = predictor_stats["min"]
        predictor_max = predictor_stats["max"]

        res = []
        to_test = list(np.linspace(predictor_min, predictor_max, num=20))
        # to_test.append(np.nan)
        for i in to_test:
            df = df.copy().sample(2000, random_state=42)
            df[predictor] = i
            m = pd.Series(xgb_model[0].predict_proba(df[self.projectParameters.predictors_continuous])[:, 1]).mean()
            if i != i:
                res.append((predictor_min - 1, m))
            else:
                res.append((i, m))

        t = pd.DataFrame(res)
        t.columns = [predictor, xgb_model[1]]
        t = t.set_index(predictor)
        self.table = t
        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        import matplotlib.pyplot as plt

        ax = self.table.plot(
            title="Association of " + self.predictors[0] + " with score " + self.projectParameters.model[1]
        )
        ax.set_xticks(list(np.arange(self.table.shape[0])))
        ax.set_xticklabels(self.table.index)
        plt.show()

    def get_description(self):
        return (
            "Association of predictor "
            + self.predictors[0]
            + " with score "
            + self.projectParameters.model[1]
            + " on sample "
            + self.samples[0][1]
        )


class IceplotMatrixCalculator(Calculator):
    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictors = self.predictors
        xgb_model = self.projectParameters.model
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        # def  f(predictor):
        #    ipc = IceplotCalculator(self.projectParameters)
        #    ipc.s([self.samples[0]]).p([predictor]).calculate()

        import multiprocessing as mp

        arr = []
        for predictor in predictors:
            ipc = IceplotCalculator(self.projectParameters)
            ipc.s([self.samples[0]]).p([predictor])
            arr.append(ipc)

        pool = mp.Pool(processes=2)
        arr = pool.map(self.f, arr)
        pool.close()
        # print(result_list)

        self.table = arr
        return self

    def get_table(self):
        return None

    def get_visualization(self):
        from matplotlib import pyplot as plt
        import math

        arr = self.table
        nrows_ = math.ceil(len(arr) / 5)
        fig, axes = plt.subplots(nrows=nrows_, ncols=5, figsize=(nrows_ * 2, 60))

        for i in range(0, len(arr)):
            arr[i].get_table().plot(
                ax=axes[int(i / 5)][i % 5], use_index=True, title=arr[i].get_table().index.name
            ).set_xlabel("")
        plt.show()

    def get_description(self):
        return (
            "Association of multiple predictors "
            + "with score "
            + self.projectParameters.model[1]
            + " on sample "
            + self.samples[0][1]
        )

    def f(self, x):
        return x.calculate()


# expect one sample, one predictor, no target
# computes and plots partial dependence plots (including missing values) and number of observations in each interval
# expect a booster (scikit-learn), model name and a list of model features
# - XGB - pp.model = (booster_xgb, 'XGB', booster_xgb.get_booster().feature_names)
# - LGBM - pp.model = (booster_lgbm, 'LGBM', booster_lgbm.booster_.feature_name())
# optionally you can set output folder (pp.output_folder) where to save plots

import matplotlib.pyplot as plt
import xgboost as xgb
import re
import warnings


class PartialDependencePlotCalculator(Calculator):
    def calculate(self):
        warnings.filterwarnings("ignore")

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        predictor = self.predictors[0]
        model = self.projectParameters.model
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        # ---------------------------------

        booster = model[0]
        feature_names = model[2]
        ale = []
        ice_df = pd.DataFrame()
        inf_finite = (-999999, 999999)  # values to be used as a proxy for -inf/+inf
        precision = 4  # number of decimals

        # find splits in xgb model, get unique values rounded to 4 decimals
        if str(type(booster)).endswith("'xgboost.sklearn.XGBClassifier'>"):
            xgdump = booster.get_booster().get_dump()
            values = []
            regexp = re.compile("\[{0}<([\d.Ee+-]+)\]".format(predictor))
            for i in range(len(xgdump)):
                m = re.findall(regexp, xgdump[i])
                values.extend(map(float, m))
            values = np.round(values, precision)
            values = np.unique(values)

            grid = [inf_finite[0]] + list(values) + [inf_finite[1]] + ["missing"]

        # use quantile grid for other models (LightGBM, etc.)
        else:
            predictor_min = df[predictor].quantile(q=0.01)  # min
            predictor_max = df[predictor].quantile(q=0.99)  # max
            grid = (
                [inf_finite[0]]
                + list(np.round(np.linspace(predictor_min, predictor_max, num=20), precision))
                + [inf_finite[1]]
                + ["missing"]
            )

        for i in range(len(grid)):

            # Category bin
            if grid[i] == "missing":
                category = "missing"
            else:
                left = grid[i]
                if i >= len(grid) - 2:
                    right = np.inf
                else:
                    right = grid[i + 1]

                category = pd.Interval(left, right, closed="left")

            # PDP, ICE
            if df.shape[0] > 2000:
                df2 = df.sample(2000, random_state=42)
            else:
                df2 = df.copy()

            if grid[i] == "missing":
                df2.loc[:, predictor] = np.nan
            else:
                df2.loc[:, predictor] = grid[i]

            ice_df = ice_df.append(pd.DataFrame(booster.predict_proba(df2[feature_names])[:, 1], columns=[category]).T)

            # ALE
            if grid[i] == "missing":
                ale.append((category, np.nan))

            elif i == 0 and i < len(grid) - 1:
                ale.append((category, 0))

            elif i > 0 and i < len(grid) - 1:
                df2 = df.loc[(df[predictor] >= grid[i - 1]) & (df[predictor] < grid[i]), :]

                if df2.shape[0] > 0:
                    df2.loc[:, predictor] = grid[i - 1]
                    pred_lower = booster.predict_proba(df2[feature_names])[:, 1]
                    df2.loc[:, predictor] = grid[i]
                    pred_upper = booster.predict_proba(df2[feature_names])[:, 1]

                    ale.append((category, (pred_upper - pred_lower).mean()))

                else:
                    ale.append((category, np.nan))

            del df2

        ale = pd.DataFrame(ale, columns=["category", "LE"]).set_index("category")
        ale.loc[:, "ALE"] = ale["LE"].cumsum()
        ale.loc[:, "ALE"] = ale["ALE"] - ale["ALE"].mean() + booster.predict_proba(df[feature_names])[:, 1].mean()

        grid = sorted(list(set(grid[:-1])))
        cut = (
            pd.cut(df[predictor], grid + [np.inf], precision=precision, right=False)
            .values.add_categories("missing")
            .fillna(value="missing")
        )
        obs = df.groupby(cut)[[rowid_col]].count()
        obs = obs.rename(columns={rowid_col: "Observations"})

        table = pd.DataFrame(ice_df.mean(axis=1), columns=["PDP"])
        table.loc[:, "PDP - median"] = ice_df.median(axis=1)
        table.loc[:, "PDP - 0.25 quantile"] = ice_df.quantile(q=0.25, axis=1)
        table.loc[:, "PDP - 0.75 quantile"] = ice_df.quantile(q=0.75, axis=1)
        table = table.join(ale["ALE"], how="left")
        table = table.join(obs, how="left")
        self.table_orig = table

        # Group by over PDP to remove duplicates, category intervals must be changed accordingly
        agg_dict = {
            "PDP": np.mean,
            "PDP - median": np.mean,
            "PDP - 0.25 quantile": np.mean,
            "PDP - 0.75 quantile": np.mean,
            "ALE": np.mean,
            "Observations": np.sum,
            "left": np.min,
            "right": np.max,
        }

        table_agg = table[:-1].copy()
        table_agg["left"] = [float(col.left) for col in table_agg.index]
        table_agg["right"] = [float(col.right) for col in table_agg.index]
        table_agg = table_agg.groupby("PDP").agg(agg_dict)
        table_agg["category"] = table_agg.apply(lambda x: pd.Interval(x["left"], x["right"], closed="left"), axis=1)
        table_agg = table_agg.set_index("category").sort_index()
        table_agg = table_agg.append(table.loc["missing", :])
        table = table_agg.drop(["left", "right"], axis=1)

        self.table = table
        self.ice_df = ice_df
        self.ale = ale
        self.obs = obs
        return self

    def get_table(self):
        return self.table

    def get_visualization(self, output_folder=None):
        model = self.projectParameters.model

        fig, ax1 = plt.subplots(figsize=(10, 5))
        plt.xticks(range(len(self.table)), self.table.index, rotation=90)
        ax1.plot(range(len(self.table)), self.table["PDP"], color="k", label="PDP - mean")  # mean - PDP
        ax1.plot(range(len(self.table)), self.table["PDP - median"], linestyle="--", label="PDP - median")  # median
        ax1.plot(
            range(len(self.table)), self.table["PDP - 0.25 quantile"], linestyle="--", label="PDP - 0.25 quantile"
        )  # quantile 0.25
        ax1.plot(
            range(len(self.table)), self.table["PDP - 0.75 quantile"], linestyle="--", label="PDP - 0.75 quantile"
        )  # quantile 0.75
        # ax1.plot(range(len(self.table)), self.ice_df.iloc[:,0:20], alpha=0.5, linewidth=1) # ICE
        ax1.plot(range(len(self.table)), self.table["ALE"], color="y", marker="o", label="ALE")  # ALE
        ax1.set_ylabel("Prediction")
        ax1.legend(loc="center left", bbox_to_anchor=(1.15, 0.5))

        ax2 = ax1.twinx()
        ax2.grid(False)
        ax2.bar(range(len(self.table)), self.table["Observations"], width=0.5, alpha=0.5)
        ax2.set_ylabel("Observations")

        plt.title(self.get_description())

        if output_folder is not None:
            plt.savefig(output_folder + "/pdp_" + self.predictors[0] + ".png", format="png", dpi=72, bbox_inches="tight")

        plt.show()
        return self

    def get_description(self):
        return (
            "Association of predictor "
            + self.predictors[0]
            + " with score "
            + self.projectParameters.model[1]
            + " on sample "
            + self.samples[0][1]
        )


from sklearn.metrics import roc_curve, roc_auc_score
import matplotlib.pyplot as plt


class ScoreGiniInTimeCalculator(Calculator):
    def __init__(self, *args, dropna=True, **kwargs):
        super().__init__(*args, **kwargs)
        self.dropna = dropna

    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        targets = self.targets
        scores = self.scores
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        masks = self.masks
        dropna = self.dropna
        # ---------------------------------

        def gini(y_true, y_pred, dropna=False):
            if dropna:
                df = pd.DataFrame({"y_true": y_true, "y_pred": y_pred}).dropna()
                y_true = df["y_true"]
                y_pred = df["y_pred"]

            try:
                return 2 * roc_auc_score(y_true, y_pred) - 1
            except ValueError:
                return np.nan

        results = pd.DataFrame()
        if not masks:
            masks = {"All": df.index.notnull()}

        for mask in masks:
            data_masked = df.loc[masks[mask], [t[0] for t in targets] + scores + [time_variable]]

            for target in targets:
                for score in scores:
                    grouped = data_masked.groupby(time_variable, axis=0).apply(
                        lambda x: gini(x[target[0]], x[score], dropna=dropna)
                    )
                    grouped = grouped.append(
                        pd.Series(
                            gini(data_masked[target[0]], data_masked[score], dropna=dropna),
                            index=[pd.Timestamp("2099-01-01")],
                        )
                    )

                    results = results.join(pd.DataFrame(grouped, columns=[[mask], [target[0]], [score]]), how="outer")

        # return final reults
        results.columns = pd.MultiIndex.from_tuples(results.columns)
        results = results.sort_index()
        self.table = results

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        plt.figure(figsize=(8.0, 5.5))
        for i in self.table.columns:
            plt.plot(self.table[:-1][i], label=i, marker="o")

        plt.xticks(rotation=90)
        plt.ylim([0, 1])
        plt.title("Gini in Time")
        plt.legend(loc="center left", bbox_to_anchor=(1, 0.5))
        plt.ylabel("Gini")
        plt.show()
        return self

    def get_description(self):
        if len(self.scores) == 1 and len(self.targets) == 1:
            return (
                "Gini of score "
                + self.scores[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
            )
        elif len(self.scores) > 1 and len(self.targets) > 1:
            return "Gini of multiple scores " + " on multiple targets " + "on sample " + self.samples[0][1]
        elif len(self.scores) > 1:
            return "Gini of multiple scores on target " + self.targets[0][0] + " on sample " + self.samples[0][1]
        elif len(self.targets) > 1:
            return "Gini of score " + self.scores[0] + " on multiple targets " + " on sample " + self.samples[0][1]


class ScoreLiftInTimeCalculator(Calculator):
    def __init__(self, *args, dropna=True, lift_perc=10, **kwargs):
        super().__init__(*args, **kwargs)
        self.dropna = dropna
        self.lift_perc = lift_perc

    def calculate(self):

        # declaration of all used external variables
        # -----------------------------------------
        df = self.samples[0][0]
        targets = self.targets
        scores = self.scores
        rowid_col = self.rowid_variable
        time_variable = self.time_variable
        masks = self.masks
        dropna = self.dropna
        lift_perc = self.lift_perc
        # ---------------------------------

        def lift(y_true, y_pred, lift_perc, dropna=False):
            if dropna:
                df = pd.DataFrame({"y_true": y_true, "y_pred": y_pred}).dropna()
                y_true = df["y_true"]
                y_pred = df["y_pred"]

            try:
                cutoff = np.percentile(y_pred, lift_perc)
                return y_true[y_pred <= cutoff].mean() / y_true.mean()
            except:
                return np.nan

        results = pd.DataFrame()
        if not masks:
            masks = {"All": df.index.notnull()}

        for mask in masks:
            data_masked = df.loc[masks[mask], [t[0] for t in targets] + scores + [time_variable]]

            for target in targets:
                for score in scores:
                    grouped = data_masked.groupby(time_variable, axis=0).apply(
                        lambda x: lift(x[target[0]], -x[score], lift_perc, dropna=dropna)
                    )
                    grouped = grouped.append(
                        pd.Series(
                            lift(data_masked[target[0]], -data_masked[score], lift_perc, dropna=dropna),
                            index=[pd.Timestamp("2099-01-01")],
                        )
                    )

                    results = results.join(pd.DataFrame(grouped, columns=[[mask], [target[0]], [score]]), how="outer")

        # return final reults
        results.columns = pd.MultiIndex.from_tuples(results.columns)
        results = results.sort_index()
        self.table = results

        return self

    def get_table(self):
        return self.table

    def get_visualization(self):
        plt.figure(figsize=(8.0, 5.5))
        for i in self.table.columns:
            plt.plot(self.table[:-1][i], label=i, marker="o")

        plt.ylim([1, 5])
        plt.xticks(rotation=90)
        plt.title(str(self.lift_perc) + "% Cumulative Lift in Time")
        plt.legend(loc="center left", bbox_to_anchor=(1, 0.5))
        plt.ylabel(str(self.lift_perc) + "% cumulative lift")
        plt.show()
        return self

    def get_description(self):
        if len(self.scores) == 1 and len(self.targets) == 1:
            return (
                "Lift of score "
                + self.scores[0]
                + " on target "
                + self.targets[0][0]
                + " on sample "
                + self.samples[0][1]
            )
        elif len(self.scores) > 1 and len(self.targets) > 1:
            return "Lift of multiple scores " + " on multiple targets " + "on sample " + self.samples[0][1]
        elif len(self.scores) > 1:
            return "Lift of multiple scores on target " + self.targets[0][0] + " on sample " + self.samples[0][1]
        elif len(self.targets) > 1:
            return "Lift of score " + self.scores[0] + " on multiple targets " + " on sample " + self.samples[0][1]

