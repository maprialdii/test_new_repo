# -*- coding: utf-8 -*-

"""
Home Credit Python Scoring Library and Workflow
Copyright © 2017-2019, Pavel Sůva, Marek Teller, Martin Kotek, Jan Zeller, 
Marek Mukenšnabl, Kirill Odintsov, Elena Kuchina, Jan Coufalík, Jan Hynek and
Home Credit & Finance Bank Limited Liability Company, Moscow, Russia.
All rights reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
"""



__version__ = "0.7.3"
"""Scoring module contains submodules for:
    Data exploration
    Grouping
    Model Building
    etc.
"""
import pandas as pd
import qgrid
import numpy as np
import seaborn as sns

from sqlalchemy import __version__ as sqlalchemy_version
from sklearn import __version__ as sklearn_version
from tqdm import __version__ as tqdm_version
from xgboost import __version__ as xgboost_version
from matplotlib import __version__ as matplotlib_version

from packaging import version
from scoring.tools import DisplayBox



def check_version(PSW_version, list_versions = False):
    '''Checks if scoring library is the same version as PSW notebook and for required versions of Pandas and Qgrid

    Compares version passed in argument to value of __version__ set in this module.
    Versions are compared as strings.

    Args:
        PSW_version (str): version of PSW

    Returns:
        Prints warning if versions don"t match or needed libraries are obsolete.

    '''
    if PSW_version != __version__:
        DisplayBox.yellow(f"<br />/scoring version:{__version__} <br />PSW version:     {PSW_version}", title="WARNING: Your Notebook and scoring library are different versions!")

    if version.parse(pd.__version__) < version.parse("0.23.0"):
        DisplayBox.red(f"<br />Your Pandas library is version {pd.__version__}. PSW requires at least version 0.23.0", title="WARNING")

    if version.parse(qgrid.__version__) < version.parse("1.0.3"):
        DisplayBox.red(f"<br />Your Qgrid library is version {qgrid.__version__}. PSW requires at least version 1.0.3", title="WARNING")


    if list_versions:
        print(
f"""
numpy: {np.__version__}
pandas: {pd.__version__}
sqlalchemy: {sqlalchemy_version}
sklearn: {sklearn_version}
matplotlib: {matplotlib_version}
seaborn: {sns.__version__}
tqdm: {tqdm_version}
xgboost: {xgboost_version}
qgrid: {qgrid.__version__}
"""
            )
